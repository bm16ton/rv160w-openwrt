/*
 *
 *  Copyright (C) 2007 Freescale Semiconductor, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "config.h"
#if defined(CFG_SWQOS)

#include <linux/kernel.h>
#include <linux/interrupt.h>
#include <linux/dma-mapping.h>
#include <linux/dmapool.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/list.h>
#include <linux/kthread.h>
#include <linux/hrtimer.h>
#include <linux/slab.h>

#include <asm/io.h>
#include <asm/irq.h>

#include "pfe_ctrl_hal.h"
#include "pfe_swqos.h"
#include "pfe_hif_lib.h"

#define ALIGN64(x)      (((u32)(x)) & ~0x7)

#ifndef TRUE
#define TRUE  1
#define FALSE 0
#endif

struct pfe_hif_nocpy _hif_nocpy;
struct pfe_hif_nocpy *hif_nocpy = &_hif_nocpy;

static void pfe_hif_nocpy_release_buffers(void);
static void pfe_hif_nocpy_free_descr(void);

extern PSWQOS_MTD SWQOS_mtd_alloc(void);

int SWQOS_process(int budget);
void SWQOS_stop_timer(void);


#define inc_hif_rxidx(idxname) do { idxname = (idxname + 1) & (hif_nocpy->RxRingSize - 1); } while (0)

/* pfe_hif_nocpy_rx_pkt -
 * This function receives one packet from hif_nocpy block.
 * @param[in] mtd		pointer to MTD struct, to hold info about packet
 * @return			TRUE if packet received, else FALSE
 */

int pfe_hif_nocpy_rx_pkt(PSWQOS_MTD mtd)
{
	struct hif_desc	*ThisDesc;
	class_tx_hdr_t *rx_hdr;
	class_tx_hdr_t local_rx_hdr;
	hif_swqos_hdr_t *swqos_hdr;

	//ENTER();
	ThisDesc = hif_nocpy->RxBase + hif_nocpy->RxtocleanIndex;
	if (ThisDesc->ctrl & BD_CTRL_DESC_EN)
	{
		/*Acknowledge interrupt */
		writel((HIF_INT | HIF_RXPKT_INT), HIF_NOCPY_INT_SRC);
		if (ThisDesc->ctrl & BD_CTRL_DESC_EN)
			return 0;
	}

	// packet length is obtained from swqos_hdr
	rx_hdr = DDR_PHYS_TO_VIRT(ThisDesc->data);

	__memcpy8(&local_rx_hdr, rx_hdr);

	mtd->data = (void *)rx_hdr - local_rx_hdr.start_buf_off;

	swqos_hdr = (void *)rx_hdr - sizeof(hif_swqos_hdr_t);
	if (sizeof(hif_swqos_hdr_t) == 8)
		__memcpy8(&mtd->swqos_hdr, swqos_hdr);
	else
		mtd->swqos_hdr = *swqos_hdr;

	//DPRINT("local_desc.data=%x, mtd->data=%x, swqos_hdr=%x, mtd->offset=%d, mtd->length=%d, mtd->queue=%d\n", local_desc.data, (unsigned int)mtd->data, (u32)swqos_hdr, mtd->offset, mtd->length, mtd->queue);
	//DPRINT("   swqos_hdr->swqueue=%d, swqos_hdr->hwqueue=%d, swqos_hdr->output_port=%d\n", swqos_hdr->swqueue, swqos_hdr->hwqueue, swqos_hdr->output_port);

	/*re-initialize the buffer descriptor */
	ThisDesc->data = 0;
	wmb();
	ThisDesc->ctrl =  BD_CTRL_PKT_INT_EN | BD_CTRL_LIFM | BD_CTRL_DIR | BD_CTRL_DESC_EN;

	inc_hif_rxidx(hif_nocpy->RxtocleanIndex);

	/* we made some progress, re-start rx dma in case it stopped */
	hif_nocpy_rx_dma_start();

	//EXIT();
	return 1;
}

/* pfe_bmu_free_buff -
 * Return the given buffer to BMU
 * @param[in] base	BMU base address
 * @param[in] buf	Buffer address to be freed
 */
void pfe_bmu_free_buff(void *base, u32 buf)
{
	u32 free_buf = buf & ~(DDR_BUF_SIZE-1);
	writel(free_buf, base + BMU_FREE_CTRL);
}

static inline void copy_to_lmem(u32 *dst, u32 *src, int len)
{
	int i;
	for (i = 0; i < len; i += sizeof(u32))
	{
                *dst = htonl(*src);
		dst++; src++;
	}
}

/* This function enables to send the packets by-passing HIF_NOCPY block */
int pfe_hif_nocpy_tx_packet(PSWQOS_MTD mtd)
{
	void *physaddr, *lmem_ptr, *lmem_virt_addr;
	static class_rx_hdr_t local_hdr;

	lmem_ptr = (void *)readl(BMU1_BASE_ADDR + BMU_ALLOC_CTRL);
	if (!lmem_ptr)
		return FALSE;

	physaddr = (void *)DDR_VIRT_TO_PHYS(mtd->data);

	//DPRINT("physaddr=%x, pkt_offset=%u, len=%d, outport=%u\n", (u32)physaddr, mtd->pkt_offset, mtd->length, mtd->output_port);
	//print_hex_dump(KERN_INFO, "pkt: ", DUMP_PREFIX_ADDRESS, 16, 1, (void *)mtd->data + mtd->pkt_offset, 64, 0);

	lmem_virt_addr = (void *)CBUS_PFE_TO_VIRT((u32)lmem_ptr);

        local_hdr.phyno = htons(RX_PHY_HIF_NOCPY); // For the QB HW, PHYNO will be read as 0 (bits [3:0]) so that HW parsing is done
        local_hdr.length = htons(MIN_PKT_SIZE);

        local_hdr.next_ptr = htonl((u32)physaddr);
        /*Mark checksum is correct for all packets, this will be checked by QB */
        local_hdr.status = htonl((STATUS_IP_CHECKSUM_CORRECT | STATUS_UDP_CHECKSUM_CORRECT |
                        STATUS_TCP_CHECKSUM_CORRECT | STATUS_UNICAST_HASH_MATCH | STATUS_CUMULATIVE_ARC_HIT));
	copy_to_lmem((u32 *)lmem_virt_addr, (u32 *)&local_hdr, sizeof(local_hdr));

	copy_to_lmem((u32 *)(lmem_virt_addr + LMEM_HDR_SIZE), (u32 *)&mtd->swqos_hdr, sizeof(hif_swqos_hdr_t));

	writel(lmem_ptr, CLASS_INQ_PKTPTR);
	return TRUE;
}


/** pfe_hif_nocpy_rx_poll
 *  This function is NAPI poll function to process HIF_NOCPY Rx queue.
 */
static int pfe_hif_nocpy_rx_poll(struct napi_struct *napi, int budget)
{
	int work_done;

	SWQOS_lock();
	work_done = SWQOS_process(budget);

	if (work_done < budget)
	{
		napi_complete(napi);
		ENABLE_HIF_NOCPY_RX_INTERRUPTS();
		// If a timer tick happened while we were inside SWQOS_process(), reschedule
		if (swqos_timer_tickcount != swqos_process_tickcount)
			SWQOS_schedule();
	}

	SWQOS_unlock();
	return work_done;
}


extern void SWQOS_timer_init(void);

int pfe_swqos_init(struct pfe *pfe)
{
	int err;

	printk(KERN_INFO "%s\n",__func__);
	if(!pfe_hif_nocpy_alloc_descr()) {
		goto err0;
	}

	if(!pfe_hif_nocpy_init_buffers()) {
		goto err1;
	}

	spin_lock_init(&hif_nocpy->lock);

	hif_nocpy_init();
	hif_nocpy_rx_enable();
	//hif_nocpy_tx_enable();

	writel(0x0, HIF_NOCPY_INT_ENABLE);

	/* Initilize NAPI for Rx processing */
	init_dummy_netdev(&hif_nocpy->dummy_dev);
	netif_napi_add(&hif_nocpy->dummy_dev, &hif_nocpy->napi, pfe_hif_nocpy_rx_poll, HIF_NOCPY_RX_POLL_WEIGHT);
	napi_enable(&hif_nocpy->napi);

	hif_nocpy->irq = IRQ_PFE_HIFNCPY;	//zzz change to use platform services
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,1,0)
	err = request_irq(hif_nocpy->irq, hif_nocpy_isr, 0, "pfe_hif_nocpy", hif_nocpy);
#else
	err = request_irq(hif_nocpy->irq, hif_nocpy_isr, IRQF_DISABLED, "pfe_hif_nocpy", hif_nocpy);
#endif
	if (err) {
		printk(KERN_ERR "%s: failed to get the hif_nocpy IRQ = %d\n",  __func__, hif_nocpy->irq);
		goto err2;
	}
	ENABLE_HIF_NOCPY_RX_INTERRUPTS();

	SWQOS_timer_init();

	return 0;

err2:
	pfe_hif_nocpy_release_buffers();
err1:
	pfe_hif_nocpy_free_descr();
err0:
	return -1;
}

void pfe_swqos_exit(struct pfe *pfe)
{
	napi_disable(&hif_nocpy->napi);
	SWQOS_stop_timer();

	hif_nocpy_rx_disable();
	hif_nocpy_tx_disable();
	free_irq(hif_nocpy->irq, hif_nocpy);

	pfe_hif_nocpy_release_buffers();
	pfe_hif_nocpy_free_descr();

	netif_napi_del(&hif_nocpy->napi);
}


/*
 * pfe_hif_nocpy_init_buffers
 * This function initializes the HIF_NOCPY Rx/Tx ring descriptors and
 * initializes buffer descriptor base address registers
 */
int pfe_hif_nocpy_init_buffers(void)
{
	struct hif_desc	*Thisdesc,*Firstdesc_p;

	int i=0;

	hif_nocpy->RxBase = hif_nocpy->descr_baseaddr_v;
	memset(hif_nocpy->RxBase, 0, hif_nocpy->RxRingSize * sizeof(struct hif_desc));

	/*Initialize Rx descriptors */
	Thisdesc = hif_nocpy->RxBase;
	Firstdesc_p = (struct hif_desc *)hif_nocpy->descr_baseaddr_p;

	for(i=0; i<hif_nocpy->RxRingSize; i++) {
		Thisdesc->ctrl =  BD_CTRL_PKT_INT_EN | BD_CTRL_LIFM |
			BD_CTRL_DIR | BD_CTRL_DESC_EN;
		/* Chain descriptors */
		Thisdesc->next = (u32)(Firstdesc_p+i+1);
		Thisdesc++;
	}

	/* Overwrite last descriptor to chain it to first one*/
	Thisdesc--;
	Thisdesc->next = (u32)Firstdesc_p;

	/*Initialize Rx buffer descriptor ring base address */
	writel(hif_nocpy->descr_baseaddr_p, HIF_NOCPY_RX_BDP_ADDR);

#if 0
	hif_nocpy->TxBase = hif_nocpy->RxBase + hif_nocpy->RxRingSize;
	Firstdesc_p = (struct hif_desc *)hif_nocpy->descr_baseaddr_p + hif_nocpy->RxRingSize;
	memset(hif_nocpy->TxBase, 0, hif_nocpy->TxRingSize * sizeof(struct hif_desc));

	/*Initialize tx descriptors */
	Thisdesc = hif_nocpy->TxBase;

	for(i=0; i<hif_nocpy->TxRingSize; i++) {
		/* Chain descriptors */
		Thisdesc->next = (u32)(Firstdesc_p+i+1);
		Thisdesc++;
	}
	/* Overwrite last descriptor to chain it to first one */
	Thisdesc--;
	Thisdesc->next = (u32)Firstdesc_p;

	/*Initialize Tx buffer descriptor ring base address */
	writel((u32)Firstdesc_p, HIF_NOCPY_TX_BDP_ADDR);
#endif

	//printk(KERN_INFO "%s: hif_nocpy->RxBase=0x%x, hif_nocpy->RxRingSize=0x%x, hif_nocpy->TxBase=0x%x, hif_nocpy->TxRingSize=0x%x\n", __func__, (u32)hif_nocpy->RxBase, hif_nocpy->RxRingSize, (u32)hif_nocpy->TxBase, hif_nocpy->TxRingSize);
	printk(KERN_INFO "%s: hif_nocpy->RxBase=0x%x, hif_nocpy->RxRingSize=0x%x\n", __func__, (u32)hif_nocpy->RxBase, hif_nocpy->RxRingSize);

	return TRUE;
}

/* pfe_hif_nocpy_alloc_descr -
 * Allocate buffer descriptor memory.
 */
int pfe_hif_nocpy_alloc_descr(void)
{
	void *desc_addr;
	dma_addr_t dma_addr;
	u32 len;

	len = HIF_NOCPY_RX_DESC_NT * sizeof(struct hif_desc) /*+ HIF_NOCPY_TX_DESC_NT * sizeof(struct hif_desc)*/;
	desc_addr = dma_alloc_coherent(pfe->dev, len, &dma_addr, GFP_KERNEL);

	if (!desc_addr) {
		printk(KERN_ERR "%s: Could not allocate buffer descriptors!\n", __func__);
		return FALSE;
	}

	hif_nocpy->descr_baseaddr_p = dma_addr;
	hif_nocpy->descr_baseaddr_v = desc_addr;
	hif_nocpy->RxRingSize = HIF_NOCPY_RX_DESC_NT;
	//hif_nocpy->TxRingSize = HIF_NOCPY_TX_DESC_NT;

	printk(KERN_INFO "%s: hif_nocpy->descr_baseaddr_p=0x%x, hif_nocpy->descr_baseaddr_v=0x%x, len=0x%x", __func__, (u32)hif_nocpy->descr_baseaddr_p, (u32)hif_nocpy->descr_baseaddr_v, len);

	return TRUE;
}

/* pfe_hif_nocpy_release_buffers
 */
static void pfe_hif_nocpy_release_buffers(void)
{
	struct hif_desc	*Thisdesc;
	int i=0;

	hif_nocpy->RxBase = hif_nocpy->descr_baseaddr_v;

	Thisdesc = hif_nocpy->RxBase;
	for(i=0; i<hif_nocpy->RxRingSize; i++) {
		if(Thisdesc->data){
			/*Packet pending in Rx descriptor, free it to BMU2 */
			pfe_bmu_free_buff(BMU2_BASE_ADDR, Thisdesc->data);
		}

		Thisdesc->data = 0;
		Thisdesc->status = 0;
		Thisdesc->ctrl =  0;
		Thisdesc++;
	}
}

/* pfe_hif_nocpy_free_descr -
 * Free the buffer descriptor memory
 */
static void pfe_hif_nocpy_free_descr(void)
{
	if (!hif_nocpy->descr_baseaddr_v)
		return;
	dma_free_coherent(pfe->dev,
			hif_nocpy->RxRingSize * sizeof(struct hif_desc) /*+ hif_nocpy->TxRingSize * sizeof(struct hif_desc)*/,
			hif_nocpy->descr_baseaddr_v, hif_nocpy->descr_baseaddr_p);
	hif_nocpy->descr_baseaddr_v = 0;
}


irqreturn_t hif_nocpy_isr(int irq, void *dev_id)
{
	int	hif_nocpy_int_src;

	/*Read hif_nocpy interrupt source register */
	hif_nocpy_int_src = readl(HIF_NOCPY_INT_SRC);

	if((hif_nocpy_int_src & HIF_INT) == 0)
		return(IRQ_NONE);

	if(hif_nocpy_int_src & HIF_RXPKT_INT)
	{
		DISABLE_HIF_NOCPY_RX_INTERRUPTS();
		if (napi_schedule_prep(&hif_nocpy->napi))
			__napi_schedule(&hif_nocpy->napi);
	}
	else
	{
		printk(KERN_ERR "%s: %x rcvd\n", __func__, hif_nocpy_int_src);
	}

	/*Acknowledge interrupt */
	//writel(hif_nocpy_int_src, HIF_NOCPY_INT_SRC);

	return IRQ_HANDLED;
}

#endif //defined(CFG_SWQOS)
