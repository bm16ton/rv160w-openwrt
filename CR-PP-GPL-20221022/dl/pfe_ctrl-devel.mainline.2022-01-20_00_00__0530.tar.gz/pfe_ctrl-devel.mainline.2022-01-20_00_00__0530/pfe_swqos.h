#ifndef _PFE_SWQOS_H_
#define _PFE_SWQOS_H_

#include "module_swqos.h"
#include "swqos_mtd.h"

#define HIF_NOCPY_RX_POLL_WEIGHT	32

#define MIN_PKT_SIZE           64
#define ETH_MAXFRAMESIZE	1518
#define HIF_NOCPY_RX_DESC_NT		512
//#define	HIF_NOCPY_TX_DESC_NT		256

/* Hardware definition of physical ports */
/* CLASS rx header phy number */
enum CLASS_RX_PHY {
	RX_PHY_0 = 0x0,
	RX_PHY_1,
	RX_PHY_2,
	RX_PHY_HIF,
	RX_PHY_HIF_NOCPY,
	RX_PHY_CLASS = 1 << 14, /**< Control bit (in PHYNO field) used to inform CLASS PE that packet comes from Class. */
	RX_PHY_UTIL = 1 << 15 /**< Control bit (in PHYNO field) used to inform CLASS PE that packet comes from UtilPE. */
};

#define STATUS_BAD_FRAME_ERR            (1<<16) /* This is set for all errors (including checksums if enabled) except overlow */
#define STATUS_LENGTH_ERR               (1<<17)
#define STATUS_CRC_ERR                  (1<<18)
#define STATUS_TOO_SHORT_ERR            (1<<19)
#define STATUS_TOO_LONG_ERR             (1<<20)
#define STATUS_CODE_ERR                 (1<<21)
#define STATUS_MC_HASH_MATCH            (1<<22)
#define STATUS_CUMULATIVE_ARC_HIT       (1<<23)
#define STATUS_UNICAST_HASH_MATCH       (1<<24)
#define STATUS_IP_CHECKSUM_CORRECT      (1<<25)
#define STATUS_TCP_CHECKSUM_CORRECT     (1<<26)
#define STATUS_UDP_CHECKSUM_CORRECT     (1<<27)
#define STATUS_OVERFLOW_ERR             (1<<28) /* GPI error */

struct pfe_hif_nocpy {
	/* To store registered clients in hif layer */
	void	*descr_baseaddr_v;
	unsigned long	descr_baseaddr_p;
	int	irq;

	struct hif_desc *RxBase;
	u32	RxRingSize;
	u32	RxtocleanIndex;
	u32	RxtofillIndex;

#if 0
	struct hif_desc *TxBase;
	u32	TxRingSize;
	u32	Txtosend;
#endif

	struct device *dev;

	spinlock_t lock;
	struct net_device	dummy_dev;
	struct napi_struct napi;
};

extern struct pfe_hif_nocpy *hif_nocpy;

typedef struct {
	u32     next_ptr;       /* ptr to the start of the first DDR buffer */
	u16     length;         /* total packet length */
	u16     phyno;          /* input physical port number */
	u32     status;         /* gemac status bits */
	u32     status2;            /* reserved for software usage */
} class_rx_hdr_t;

typedef struct {
	u8	start_data_off;		/* packet data start offset, relative to start of this tx pre-header */
	u8	start_buf_off;		/* this tx pre-header start offset, relative to start of DDR buffer */
	u16	pkt_length;		/* total packet length */
	u8	act_phyno;		/* action / phy number */
	u8	queueno;		/* queueno */
	u16	unused;
} class_tx_hdr_t;

int pfe_hif_nocpy_rx_pkt(PSWQOS_MTD mtd);
void pfe_bmu_free_buff(void *base, u32 buf);
int pfe_hif_nocpy_tx_packet(PSWQOS_MTD mtd);

int pfe_swqos_init(struct pfe *pfe);
void pfe_swqos_exit(struct pfe *pfe);

int pfe_hif_nocpy_init_buffers(void);
int pfe_hif_nocpy_alloc_descr(void);

irqreturn_t hif_nocpy_isr(int irq, void *dev_id);

#endif /* _PFE_SWQOS_H_ */
