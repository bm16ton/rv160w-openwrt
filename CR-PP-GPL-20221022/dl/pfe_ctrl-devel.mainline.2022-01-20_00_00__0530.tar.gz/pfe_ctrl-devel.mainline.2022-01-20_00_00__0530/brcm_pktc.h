/* Copyright (c) 2008-2015 NXP Semiconductor, Inc.
 * All rights reserved.
 * THIS SOFTWARE IS PROVIDED BY NXP Semiconductor ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NXP Semiconductor BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef _BRCM_PKTC_H_
#define _BRCM_PKTC_H_

/*Max chainable PKTC clients */
#define PKTCMC 8
/* Max packet per client to bundle */
#define PKTCBND 48
/* Extra head room for BRCM Packets */
#define BRCMHEADROOM 80

int g_maxChainNum = VWD_RX_POLL_WEIGHT;
module_param(g_maxChainNum, int, 0600);

/* Chain params */
struct chain_node {
        struct sk_buff  *link;    /*Next SKB */
        unsigned int    flags:3, pkts:9, bytes:20;
};

/* Chain List */
struct pktc_data {
        void    *chead;         /* chain head */
        void    *ctail;         /* chain tail */
        uint8_t   *h_da;          /* pointer to da of chain head */
        uint8_t   *h_sa;          /* pointer to sa of chain head */
        uint8_t   h_prio;         /* prio of chain head */
};

typedef struct pktc_data pktc_data_t;

/* compare two ethernet addresses - assumes the pointers can be referenced as shorts */
#define eacmp(a, b)     ((((const uint16_t *)(a))[0] ^ ((const uint16_t *)(b))[0]) | \
                         (((const uint16_t *)(a))[1] ^ ((const uint16_t *)(b))[1]) | \
                         (((const uint16_t *)(a))[2] ^ ((const uint16_t *)(b))[2]))

#define PKTLEN(skb)     ((struct sk_buff*)(skb))->len
#define CHAINED (1 << 3)
#define CHAIN_NODE(skb)         ((struct chain_node*)(((struct sk_buff*)skb)->pktc_cb))
#define PKTSETCLINK(skb, x)     (CHAIN_NODE(skb)->link = (struct sk_buff*)(x))

#define PKTCENQTAIL(h, t, p) \
do { \
        if ((t) == NULL) { \
                (h) = (t) = (p); \
        } else { \
                PKTSETCLINK((t), (p)); \
                (t) = (p); \
        } \
} while (0);

#define PKTCINCRCNT(skb)        CHAIN_NODE(skb)->pkts++                                 /* Incrment No of packets count */
#define PKTSETCHAINED(skb)      (((struct sk_buff*)(skb))->pktc_flags |= CHAINED)       /* Set chained flag */
#define PKTISCHAINED(skb)       (((struct sk_buff*)(skb))->pktc_flags & CHAINED)        /* Check chained flag */
#define PKTCLRCHAINED(skb)      (((struct sk_buff*)(skb))->pktc_flags &= (~CHAINED))    /* Clear chained flag */
#define PKTCCLRFLAGS(skb)       (CHAIN_NODE(skb)->flags = 0)                            /* Clear pktc flags */
#define PKTCLINK(skb)           (CHAIN_NODE(skb)->link)
#define PKTCADDLEN(skb, l)      (CHAIN_NODE(skb)->bytes += (l))
#define PKTCCNT(skb)            (CHAIN_NODE(skb)->pkts)
#define PKTCLEN(skb)            (CHAIN_NODE(skb)->bytes)
#define PKTSETPRIO(skb, x)      (((struct sk_buff*)(skb))->priority = (x))

#define FOREACH_CHAINED_PKT(skb, nskb) \
        for (; (skb) != NULL; (skb) = (nskb)) \
                if ((nskb) = (PKTISCHAINED(skb) ? PKTCLINK(skb) : NULL), \
                    PKTSETCLINK((skb), NULL), 1)

#define FALSE 0
#define TRUE  1

static void pfe_vwd_send_to_vap(struct vap_desc_s *vap, struct sk_buff *skb, struct net_device *dev);

/*
 * send Chained packet to BRCM
 */
static inline void sendup_chain(unsigned int cidx, pktc_data_t *cd, struct vap_desc_s *vap, struct net_device *dev)
{
       unsigned int index;
        for (index = 0;( index <= cidx && index < PKTCMC); index++) {
                if (cd[index].chead != NULL) {
                       pfe_vwd_send_to_vap(vap, cd[index].chead, dev);
                }
        }
}

/*
 * Compares the Sa and Da and chains the packet.
 */
static inline bool is_chained (pktc_data_t *cd, unsigned int *cidx, struct ethhdr *hdr, struct sk_buff *skb)
{
       unsigned int index;

       if (unlikely(cd[0].h_da == NULL)) {
               cd[0].h_da = hdr->h_dest; 
               cd[0].h_sa = hdr->h_source;
               cd[0].h_prio = 0;
       }

       for(index = 0;index <= *cidx;index++) {
               if(!eacmp(hdr->h_dest, cd[index].h_da) && !eacmp(hdr->h_source, cd[index].h_sa)) {
                       break;
                } else if ((index + 1 < PKTCMC) && (cd[index+1].h_da == NULL)){
                       *cidx = *cidx + 1;
                       cd[*cidx].h_da = hdr->h_dest;
                       cd[*cidx].h_sa = hdr->h_source;
                       cd[*cidx].h_prio = 0;
                }
       }

       /* entry matched or new entry created in cd[] */
       if ((index < PKTCMC) && ((cd[index].chead == NULL ? TRUE : PKTCCNT(cd[index].chead)) < g_maxChainNum)) {
               /* enqueue chainable packet into cd's list */
               PKTSETCHAINED(skb);
               PKTCENQTAIL(cd[index].chead, cd[index].ctail, skb);
               PKTCINCRCNT(cd[index].chead);
               PKTCADDLEN(cd[index].chead, PKTLEN(skb));
               return TRUE;
       }

       return FALSE;
}
#endif /* _BRCM_PKTC_H_ */
