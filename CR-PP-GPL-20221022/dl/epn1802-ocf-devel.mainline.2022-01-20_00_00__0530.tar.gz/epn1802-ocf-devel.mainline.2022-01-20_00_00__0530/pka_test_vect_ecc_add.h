//[GOOD]pka_ecc_padd_1914
unsigned int eccadd_a[] = {
0xBE03DD19,
0xF16BF0DD,
0x0993831A,
0x58145473,
0xA9B4F22E
};
unsigned int eccadd_b[] = {
0x3FA193A6,
0x72AFADD8,
0xBF6AC2C4,
0xC7CECB79,
0xCA7B8250
};

unsigned int eccadd_m[] = {
0x5895232C,
0xDE2F9A5E,
0x7872B2FB,
0x35F42459,
0x30B07612
};
	
unsigned int eccadd_mp[] = {
0xB39FCBFB,
0x93EC333C,
0x3F9E47DA,
0xF959E11D,
0x23D9BE04
};
unsigned int eccadd_size = 160;
unsigned int eccadd_curve = 0;

unsigned int eccadd_x[] = {
0x24EC3B24,
0xD5BC06FE,
0x90C98672,
0x26C9A58B,
0x08B7F6DC
};


unsigned int eccadd_y[] = {
0x540B48DF,
0x6012688F,
0x79139A0E,
0xBBD58F55,
0xFF62CD2A
};

