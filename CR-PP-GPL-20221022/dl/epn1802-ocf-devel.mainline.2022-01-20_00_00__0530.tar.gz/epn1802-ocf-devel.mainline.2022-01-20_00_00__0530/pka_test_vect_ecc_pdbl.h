//[GOOD]pka_ecc_pdbl_2023
unsigned int eccpdbl_a[] = {
0x03F0265D,
0x5A11A91B,
0x6991A0F5,
0xE7049A2B,
0xFBA64AE7
};
unsigned int eccpdbl_b[] = {
0xADE196E8,
0xA8A753F8,
0xFCC5CBB0,
0x2009F591,
0xA254CA58
};
unsigned int eccpdbl_size =160;
unsigned int eccpdbl_curve = 0;

unsigned int eccpdbl_rx[] = {
0xA3C2E57E,
0x5303B680,
0x868DDCFB,
0x3285C721,
0x76FBB1D0

};


unsigned int eccpdbl_ry[] = {
0x16FDC051,
0x0F878094,
0xE004EAE7,
0x11AF52A8,
0x8873D9D2
};

