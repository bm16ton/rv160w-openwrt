unsigned int eccpverf_x[] = {
0x7FA857DF,
0x12FA3020,
0xF6AF92F1,
0xFA94D331,
0x53A640A7
};
unsigned int eccpverf_y[] = {
0x856E8CDE,
0xA1E46D20,
0xB1BD167E,
0xBE73098B,
0x21335CEB
};
unsigned int eccpverf_curve = 0;
unsigned int eccpverf_size  = 160;
