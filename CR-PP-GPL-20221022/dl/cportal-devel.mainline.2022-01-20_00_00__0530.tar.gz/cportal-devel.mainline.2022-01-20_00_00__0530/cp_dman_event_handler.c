#include "cp_main.h"
#include "cp_dman.h"
#include "capportald.h"
#include "cp_client_list.h"
#include "cp_nf_rules.h"
#include "cp_netfilter.h"

static int cp_dman_status_msg_process(vap_if_index_t if_index, unsigned char enable)
{
    if (cp_cfg[if_index].enabled == enable) {
        return SUCCESS;
    }

    cp_cfg[if_index].enabled = enable;

    if (enable == TRUE) {
        _cp_client_list_init(if_index);

        if (_cp_init_socket(if_index) == FAILURE) {
            CP_ERROR(1, "_cp_init_socket failed");
            return FAILURE;
        }
        if (_cp_init_nf_rules (if_index) == FAILURE) {
            CP_ERROR(1, "_cp_init_nf_rules failed");
            return FAILURE;
        }
    } else {
        cp_flush_vap_rules(if_index);
        close_registered_sockets(if_index);	
        destroy_client_list(if_index);
    }

    return SUCCESS;
}

static int cp_dman_splash_url_msg_process(vap_if_index_t if_index, char *url)
{
    strncpy(cp_cfg[if_index].splash_url, url, SPLASH_URL_LEN);
    return SUCCESS;
}

static int cp_dman_cloud_provider_msg_process(vap_if_index_t if_index, int cloud_provider)
{
    cp_cfg[if_index].cloud_provider = cloud_provider;
    return SUCCESS;
}

static int cp_dman_timeout_msg_process(vap_if_index_t if_index, int timeout)
{
    cp_cfg[if_index].timeout = timeout;
    return SUCCESS;
}

static int
cp_dman_message_process (char *buf)
{
    cmd_type msg_type = 0;
    captive_sock_t *cp_dman_sock;
    int rc = 0;

    /* The first byte of the message has to be
     * message type or else the message is invalid.
     */
    /* msg_type = (cmd_type) buf[0]; */
    cp_dman_sock = (captive_sock_t *) buf;

    switch (cp_dman_sock->cmd_id) {
        case CP_DMAN_STATUS_NOTIFY:
            CP_ERROR (1, "Got status change notification from DMAN.\n");
            rc = cp_dman_status_msg_process (cp_dman_sock->if_index, cp_dman_sock->u.status);
            if (rc == FAILURE) {
                cp_cfg[cp_dman_sock->if_index].enabled = !(cp_cfg[cp_dman_sock->if_index].enabled);
            }
            dns_send_sock(buf);	
            break;
        case CP_DMAN_SPLASH_URL_NOTIFY:
            CP_ERROR (1, "Got splash-url change notification from DMAN.\n");
            rc = cp_dman_splash_url_msg_process (cp_dman_sock->if_index, cp_dman_sock->u.splash_url);
            break;
        case CP_DMAN_WALLED_GARDEN_NOTIFY:
            CP_ERROR (1, "Got walled-garden change notification from DMAN.\n");
            dns_send_sock(buf);	
            break;
        case CP_DMAN_INACTIVITY_TIMEOUT_NOTIFY:
            CP_ERROR(1,"Got the inactivity timeout change notification from DMAN.\n");
            rc = cp_dman_timeout_msg_process(cp_dman_sock->if_index,cp_dman_sock->u.timeout);
            break;
        default:
            CP_ERROR (1, "%s: Got unknown notify event (0x%x).\n",
                    __func__, msg_type);
            rc = FAILURE;
    }
    return rc;
}	
/* Socket program to send the modified parameter to the cportald*/
int dns_send_sock(char  *cp_sock)
{
    int sock_id;
    struct sockaddr_un own;
    sock_id = socket(AF_LOCAL, SOCK_DGRAM, 0);

    if(sock_id < 0){
        return -1;
    }
    CP_ERROR(1,"socket creatde\n");
    memset(&own, 0 ,sizeof(own));
    own.sun_family = AF_LOCAL;
    snprintf(own.sun_path, sizeof(own.sun_path), "%s", DNS_DMAN_SOCK);
    if(sendto(sock_id, cp_sock, sizeof(captive_sock_t), 0, (struct sockaddr*)&own, sizeof(struct sockaddr_un)) < 0){
        CP_ERROR(1,"socket creatde\n");
        return -1;
    }
    CP_ERROR(1,"socket creatde\n");
    close(sock_id);
    return 0;
}

int
cp_dman_event_process (int sock, void *eloop_ctx, void *user_data)
{
    int data_len = 0;
    struct sockaddr_un from_addr;
    int from_len = sizeof (from_addr);
    char buf[CP_DMAN_MSG_SIZE_MAX];
    memset (buf, 0, CP_DMAN_MSG_SIZE_MAX);
    memset (&from_addr, 0, sizeof (from_addr));
    data_len = recvfrom (sock, buf, CP_DMAN_MSG_SIZE_MAX, 0,
            (struct sockaddr *) &from_addr, &from_len);
    if (data_len < 1) {
        return FAILURE;
    }
    CP_ERROR (1, "Rxd event from DMAN process.\n");

    if (cp_dman_message_process (buf) == FAILURE) {
        CP_ERROR (2, "msg process failed");
        return FAILURE;
    }
    return SUCCESS;
}

