#include <sys/socket.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <linux/if_arp.h>
#include "cp_main.h"
#include "cp_netfilter.h"
#include "cp_client_list.h"
#include "cp_util.h"

/*  arp_flags and at_flags field values */
#define ATF_INUSE   0x01    /* entry in use */
#define ATF_COM     0x02    /* completed entry (enaddr valid) */
#define ATF_PERM    0x04    /* permanent entry */
#define ATF_PUBL    0x08    /* publish entry (respond for other host) */
#define ATF_USETRAILERS 0x10    /* has requested trailers */
#define ATF_PROXY   0x20    /* Do PROXY arp */

void recv_packet (int fd, void *eloop_ctx, void *user_data);
void remove_netfilter_queue (void);

nfq_vap_t vap[VAP_END];

static int
getclientmac (struct nfq_data *tb, nfq_vap_t * client)
{
    int id = 0;
    struct nfqnl_msg_packet_hdr *ph;
    struct nfqnl_msg_packet_hw *hwph;
    int ret;
    unsigned char *buffer;
    int len;

    ph = nfq_get_msg_packet_hdr (tb);
    if (ph)
    {
        id = ntohl (ph->packet_id);
    }
    CP_ERROR (1, "got packet id FILE:%s-FUNCTION:%s-LINE:%d", __FILE__,
            __func__, __LINE__);
    hwph = nfq_get_packet_hw (tb);
    if (hwph)
    {
        int i, hlen = ntohs (hwph->hw_addrlen);
        for (i = 0; i < 6; i++)
        {
            client->client.mac[i] = hwph->hw_addr[i];
        }
        client->client.mac[i] = 0;
    }
    ret = nfq_get_payload (tb, &buffer);
    if ((ret >= 0))
    {
        printf ("payload_len=%d bytes", ret);
        fputc ('\n', stdout);
    }

    // parse the packet headers
    struct iphdr *iph = ((struct iphdr *) buffer);

    CP_ERROR (1,
            "IP{v=%u; ihl=%u; tos=%u; tot_len=%u; id=%u; ttl=%u; protocol=%u; ",
            iph->version, iph->ihl * 4, iph->tos, ntohs (iph->tot_len),
            ntohs (iph->id), iph->ttl, iph->protocol);

    // if protocol is tcp
    if (iph->protocol == IPPROTO_TCP)
    {
        struct tcphdr *tcp = ((struct tcphdr *) (buffer + (iph->ihl << 2)));
        safe_memcpy (&client->client.ipv4, (struct in_addr *)&iph->saddr, sizeof (struct in_addr));
        CP_ERROR(1,"%s\n",inet_ntoa(client->client.ipv4));
        client->dst_port = ntohs (tcp->dest);
        CP_ERROR(1,
                "TCP{sport=%u; dport=%u; seq=%u; ack_seq=%u; flags=u%ua%up%ur%us%uf%u; window=%u; urg=%u}\n",
                ntohs (tcp->source), ntohs (tcp->dest), ntohl (tcp->seq),
                ntohl (tcp->ack_seq), tcp->urg, tcp->ack, tcp->psh, tcp->rst,
                tcp->syn, tcp->fin, ntohs (tcp->window), tcp->urg_ptr);
    } else {
        CP_ERROR(1, "%s: Not a TCP packet (proto=0x%x), skipping it", __func__, iph->protocol);
    }

    CP_ERROR (1, "Success full packet parseing FILE:%s-FUNCTION:%s-LINE:%d",
            __FILE__, __func__, __LINE__);
    return id;
}

/* Alarm handler for ensured shutdown */
static void redir_alarm(int signum)
{
    CP_ERROR(1, "Client process timed out - %d\n", getpid());
    exit(0);
}

static int cp_get_ip_from_arpentry(nw_addr_t *client_addr, char *dev_name)
{
    int s;
    struct arpreq arpreq;
    struct sockaddr_in *sin;
    unsigned char *mac;

    memset(&arpreq, 0, sizeof(arpreq));

    sin = (struct sockaddr_in *) &arpreq.arp_pa;
    sin->sin_family = AF_INET;
    sin->sin_addr.s_addr = client_addr->ipv4.s_addr;
    /*#TODO Name should take it from dev_name arg */
    if(dev_name == NULL) {
        strcpy(arpreq.arp_dev, "br-vlan1");
    } else {
        strcpy(arpreq.arp_dev, dev_name);
    }

    s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0) {
        perror("socket");
        return FAILURE;
    }
    if (ioctl(s, SIOCGARP, &arpreq) < 0) {
        perror("ioctl");
        printf("ARP resolve error\n");
        return FAILURE;
    }
    if (arpreq.arp_flags & ATF_COM) {
        mac = (unsigned char *) &arpreq.arp_ha.sa_data[0];
        if (safe_memcpy (client_addr->mac, mac, MAC_ADDR_LEN) == FAILURE) {
            CP_ERROR (1,
                    "Memory copy failed in the function  FILE:%s-FUNCTION:%s-LINE:%d",
                    __FILE__, __func__, __LINE__);
            return FAILURE;
        }
    }
    close(s);
    return SUCCESS;
}


void
cp_handle_request (int fd, void *eloop_ctx, void *user_data)
{
    unsigned short int ret;
    unsigned int instance = (unsigned int) user_data;
    unsigned char do_redir = (unsigned char) IS_INSTANCE_REDIR(instance);
    unsigned char do_ssl = (unsigned char) IS_INSTANCE_SSL(instance);
    vap_if_index_t index = GET_VAP_INSTANCE(instance);
    client_node_t *node = NULL;
    struct sockaddr_in client_addr;
    nw_addr_t client_details = {'\0'};
    socklen_t len = sizeof(struct sockaddr_in);
    int sock;
    int add_bypass_rule = FALSE;

    safe_memset((void *)&client_addr, 0, sizeof(struct sockaddr_in));

    if ((sock = accept(fd, (struct sockaddr *)&client_addr, &len)) == FAILURE) {
        CP_ERROR(1,"client connnection accept failed");
        return;
    }
    CP_ERROR(1,"client connnection accepted, with conn_fd = %d", sock);

    if (ndelay_on(sock) < 0) {
        CP_ERROR(1, "Error setting Non-blocking mode for fd (%d)", sock);
    }

    if (client_addr.sin_family != AF_INET) {
        CP_ERROR(1,"Can't handle non-IPv4 packets");
        close(sock);
        return;
    }

    client_details.ipv4.s_addr = client_addr.sin_addr.s_addr;
    if (cp_get_ip_from_arpentry(&client_details, cp_cfg[index].wki.br_name) == FAILURE) {
        CP_ERROR (1,
                "ARP resolving for client rule addition failed in the function FILE:%s-FUNCTION:%s-LINE:%d", 
                __FILE__, __func__, __LINE__);
        close (sock);
        return;
    }

    if ((node = cp_client_present_check (client_details.mac, index) )== NULL) {
        CP_ERROR (1,
                "Client is not present in list but might be associated previously ");

        node = (client_node_t *) calloc (1, sizeof(client_node_t));
        if (node == NULL) {
            CP_ERROR(1, "Calloc Failure!!! %s:%d", __func__, __LINE__);
            close (sock);
            return;
        }

        safe_memcpy (&node->client.client_addr, &client_details, sizeof (nw_addr_t));
        cp_client_add_to_list (node, index);
        CP_ERROR (1, "Client added to the MAC & IP list %s (%s)",
                inet_ntoa (client_details.ipv4), mactoa(client_details.mac));
        add_bypass_rule = TRUE;
    } else if ((unsigned int)node->client.client_addr.ipv4.s_addr == 0) {
        client_node_t *node2 = NULL;
        node2 = (client_node_t *) calloc (1, sizeof(client_node_t));
        if (node2 == NULL) {
            CP_ERROR(1, "Calloc Failure!!! %s:%d", __func__, __LINE__);
            close (sock);
            return;
        }
        CP_ERROR (1, "Client IP addr (%s) not updated ",
                inet_ntoa (client_details.ipv4));
        safe_memcpy (&node->client.client_addr.ipv4, &client_details.ipv4, sizeof(struct in_addr));
        safe_memcpy (&node2->client, &node->client, sizeof(client_list_t));
        cp_client_list_main(INSERT_IP, node2, index);
        CP_ERROR (1, "Client added to the IP list %s (%s)",
                inet_ntoa (client_details.ipv4), mactoa(client_details.mac));
    } else {
        CP_ERROR (1, "Client is present in the list %s (%s)",
                inet_ntoa (client_details.ipv4), mactoa(client_details.mac));
    }


    /* Just to prevent mulitple additions of bypass rules */
    if (add_bypass_rule == TRUE) {
        cp_syslog(LOG_NOTICE, "Client %s (%s) on SSID \"%s\" (%s) has begun authentication",
                inet_ntoa(client_details.ipv4), mactoa(client_details.mac),
                cp_cfg[index].wki.ssid, gVapWlanMap[index]);
        if (cp_add_client_route(index, mactoa(client_details.mac),
                    inet_ntoa(client_details.ipv4))) {
            CP_ERROR (1, "Error: Cloud not add client route and ARP entries for client - %s (%s)",
                    inet_ntoa (client_details.ipv4), mactoa(client_details.mac));
        }
        if (cp_add_client_bypass_rule(index, mactoa(client_details.mac), TRUE)) {
            CP_ERROR (1, "Error: Cloud not add client NFQ by-pass rule for client - %s (%s)",
                    inet_ntoa (client_details.ipv4), mactoa(client_details.mac));
        }
    }

    ret=node->client.state.current;
    if ((ret == AUTHENTICATING || ret == UNAUTHENTICATED) && do_redir) {
        if (!node->client.initialized) {
            node->client.state.current=AUTHENTICATING;
            node->client.state.next=AUTHENTICATING + 1 ;
            node->client.initialized=1;
        }
    }

    if (fork()==0) {
        /*
         *  Setup child process
         */
        struct itimerval itval;
        client_state_e rc;
        char buf[25];
        FILE *fptr = NULL;
        snprintf(buf,25,"/tmp/cportal.%d",getpid());

        close (fd);
        eloop_register_signal(SIGALRM, redir_alarm, NULL);

        if (do_redir) {
            struct linger linger;	  
            linger.l_onoff = 1;
            linger.l_linger = 0;

            if (setsockopt (sock, SOL_SOCKET, SO_LINGER, (void *)&linger, sizeof(linger)) < 0) {
                perror ("setsockopt");
                CP_ERROR (1, "HTTP setsockopt call failed  FILE:%s-FUNCTION:%s-LINE:%d",
                        __FILE__, __func__, __LINE__);
                return;
            } else {
                CP_INFO (2, "HTTP setsockopt success  FILE:%s-FUNCTION:%s-LINE:%d",
                        __FILE__, __func__, __LINE__);
            }
        }
        memset(&itval, 0, sizeof(itval));
        itval.it_interval.tv_sec = REDIR_MAXTIME;
        itval.it_interval.tv_usec = 0;
        itval.it_value.tv_sec = REDIR_MAXTIME;
        itval.it_value.tv_usec = 0;

        if (setitimer(ITIMER_REAL, &itval, NULL)) {
            CP_ERROR(1, "setitimer() failed!");
        }

        if ((rc = cp_handle_http_request
                    (sock,node,do_ssl,do_redir, index)) == FAILURE) {
            CP_ERROR (1, "HTTP req handle failed");
        } else {
            CP_ERROR (1, "http handle req success");
        }
        if(rc != 0 && rc!= -1)
        {
            fptr=fopen(buf,"w+");
            if(fptr != NULL){
                if(node != NULL){
                    fprintf(fptr,"%d,%d,%x,%d,%s\n",rc,index,
                            node->client.client_addr.ipv4.s_addr,node->client.session_time.end,
                            node->client.pam_data.username);
                    fclose(fptr);
                }else{
                    CP_ERROR(1,"cant get structure detail\n");
                }
            }else{
                CP_ERROR(1,"Error in opening file\n");
            }
        }

        exit(rc);
    } else {
        close (sock);
    }
    return;
}

