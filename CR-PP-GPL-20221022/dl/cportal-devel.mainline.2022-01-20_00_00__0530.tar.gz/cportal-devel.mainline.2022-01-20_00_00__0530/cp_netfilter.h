#ifndef _CP_NETFILTER_H
#define _CP_NETFILTER_H 1

#include "capportald.h"
#include <libnetfilter_queue/libnetfilter_queue.h>
#include "cp_socket_init.h"

typedef struct nfq_vap
{
    struct nfq_handle *h;
    struct nfq_q_handle *qh;
    nw_addr_t client;
    int queue_fd;
    int vap_id;
    int dst_port;
} nfq_vap_t;

extern nfq_vap_t vap[VAP_END];

void cp_handle_request (int fd, void *eloop_ctx, void *user_data);

#endif
