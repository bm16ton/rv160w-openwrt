#include "cp_main.h"
#include "cp_util.h"
#include "cp_nf_rules.h"
#include "cp_socket_init.h"
#include "capportald.h"

static const char gen_rules[][50] = {
    "--ip-proto udp --ip-dport 67:68 -j ACCEPT",
    "--ip-proto tcp --ip-dport 53 -j ACCEPT",
    "--ip-proto udp --ip-dport 53 -j ACCEPT",
    "--ip-proto tcp --ip-dport 137 -j ACCEPT",
    "--ip-proto udp --ip-dport 137 -j ACCEPT",
    "--ip-proto udp --ip-dport 138 -j ACCEPT",
    "--ip-proto tcp --ip-dport 139 -j ACCEPT",
    "--ip-proto udp --ip-dport 5355 -j ACCEPT",
    "\0"
};

static const char walledG_rules[][70] = {
    "--ip-proto tcp --ip-dport 9080 -j ACCEPT",
    "\0"
};

typedef struct walled_garden {
    unsigned char domain[MAX_DOMAIN_NUM][MAX_DOMAIN_LEN+1];
} walled_garden_t;

walled_garden_t cp_walled_garden[VAP_END];

typedef struct vlan_ipv4 {
    int vlan_id;
    unsigned char ip[15];
    int  prefix_len;
} vlan_ipv4_t;

vlan_ipv4_t vlanipv4[VLAN_MAX];

static int
write_to_rules_file (char *filename, char *cmd_str)
{
    FILE *fp = NULL;
    int rc = FAILURE;

    fp = fopen (filename, "a+");
    if (fp == NULL)
    {
        perror ("Openning rule file failed");
        return FAILURE;
    }

    rc = fprintf (fp, "%s || true;\n", cmd_str);
    if (!rc)
    {
        CP_ERROR (1, "%s: Failed writing into file \"%s\"", __func__, filename);
        rc = FAILURE;
    }

    fclose (fp);
    rc = SUCCESS;
    return rc;
}

int
cp_add_rule (uint8_t command, char *rules_file_name, const char *table,
        uint8_t insert_pos, char *chain, const char *fmt, ...)
{
    int rc = 0;
    static char cmd_str[CMD_STR_LEN];
    static char match_action[CMD_STR_LEN];
    FILE *fp = NULL;
    va_list ap;
    char *cmd = NULL;

    va_start (ap, fmt);
    vsnprintf (match_action, CMD_STR_LEN, fmt, ap);
    va_end (ap);

    if (command == EBTABLES)
        cmd = EBTABLES_CMD;
    else if (command == IPTABLES)
        cmd = IPTABLES_CMD;
    else 
        cmd = IP6TABLES_CMD;

    /* Cmd string for adding to the ip/ebtables */
    if (insert_pos)
    {
        rc = snprintf (cmd_str, CMD_STR_LEN, "%s -t %s -I %s %d %s",
                cmd, table, chain, insert_pos, match_action);
    }
    else
    {
        rc = snprintf (cmd_str, CMD_STR_LEN, "%s -t %s -A %s %s",
                cmd, table, chain, match_action);
    }

    /* Executing the command */
    CP_ERROR (1, "%s: Executing the command \"%s\"", __func__, cmd_str);
    rc = exec_rule (cmd_str);
    if (rc)
    {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }

    /* Cmd string for deleting from the ip/ebtables */
    snprintf (cmd_str, CMD_STR_LEN, "%s -t %s -D %s %s",
            cmd, table, chain, match_action);

    /* Saving the delete command to the corresponding file */
    return (write_to_rules_file (rules_file_name, cmd_str));
}

int
cp_init_walled_garden_rules (vap_if_index_t if_index)
{
    char fname[RULES_FILE_NAME_LEN];
    char cname[RULES_FILE_NAME_LEN];
    int rc = 0, i;

    snprintf (fname, RULES_FILE_NAME_LEN,
            "%s/walledG.%s", CP_NF_RULE_PATH, gVapWlanMap[if_index]);
    snprintf (cname, RULES_FILE_NAME_LEN,
            "WALLG_%s", gVapWlanMap[if_index]);

    for (i = 0; ((rc == 0) && (walledG_rules[i][0] != '\0')); i++)
    {
        rc = cp_add_rule (EBTABLES, fname, "broute", NF_APPEND, cname,
                "-p IPv4 -i %s --ip-dst %s %s",
                gVapWlanMap[if_index], inet_ntoa (cp_cfg[if_index].wki.ap_addr.ipv4), walledG_rules[i]);
    }
    return rc;
}

static void cp_flush_walled_garden_rules (vap_if_index_t if_index)
{
    int i=1;
    char buffer[RULES_FILE_NAME_LEN + 20]={"\0"};
    char fname[RULES_FILE_NAME_LEN];
    snprintf (fname, RULES_FILE_NAME_LEN,
            "%s/walledG.%s", CP_NF_RULE_PATH, gVapWlanMap[if_index]);
    sprintf(buffer,"/bin/sh  %s",fname);
    CP_ERROR(1,"Executing comand for the removing the rule is %s ",buffer);
    system(buffer);

    remove(fname);
    return;
}

int
cp_init_redir_rules (vap_if_index_t if_index)
{
    char fname[RULES_FILE_NAME_LEN];
    char cname[RULES_FILE_NAME_LEN];
    int rc = 0, i;

    snprintf (cname, RULES_FILE_NAME_LEN,
            "FWALL_%s", gVapWlanMap[if_index]);

    snprintf (fname, RULES_FILE_NAME_LEN,
            "%s/firewall.%s", CP_NF_RULE_PATH, gVapWlanMap[if_index]);
    rc = cp_add_rule (EBTABLES, fname, "broute", NF_APPEND, cname,
            "-p IPv4 -i %s --ip-proto tcp --ip-dport %d -j mark --mark-set 0x%x --mark-target ACCEPT",
            gVapWlanMap[if_index], HTTP_PORT,
            VAP_BASE_HTTP_NFQ_PORT_MARK + if_index);
    if (rc)
        return rc;

    rc = cp_add_rule (EBTABLES, fname, "broute", NF_APPEND, cname,
            "-p IPv4 -i %s --ip-proto tcp --ip-dport %d -j mark --mark-set 0x%x --mark-target ACCEPT",
            gVapWlanMap[if_index], HTTPS_PORT,
            VAP_BASE_HTTPS_NFQ_PORT_MARK + if_index);
    if (rc)
        return rc;
    /*start add mark for logon process*/
    rc = cp_add_rule (EBTABLES, fname, "broute", NF_APPEND, cname,
            "-p IPv4 -i %s --ip-proto tcp --ip-dport %d -j mark --mark-set 0x%x --mark-target ACCEPT",
            gVapWlanMap[if_index], LOGON_BASE_HTTPS_PORT,
            VAP_BASE_LOGON_PORT_MARK + if_index);
    if (rc)
        return rc;
    /*add end*/

#if 0 
    rc = cp_add_rule (EBTABLES, fname, "broute", NF_APPEND, cname,
            "-p IPv4 -i %s --ip-dst %s --ip-proto tcp --ip-dport %d -j dnat --to-dst %s --dnat-target ACCEPT",
            gVapWlanMap[if_index], inet_ntoa (cp_cfg[if_index].wki.ap_addr.ipv4),
            LOGON_BASE_HTTP_PORT, mactoa(cp_cfg[if_index].wki.ap_addr.mac));
    if (rc)
        return rc;


    rc = cp_add_rule (EBTABLES, fname, "broute", NF_APPEND, cname,
            "-p IPv4 -i %s --ip-dst %s --ip-proto tcp --ip-dport %d -j dnat --to-dst %s --dnat-target ACCEPT",
            gVapWlanMap[if_index],  inet_ntoa (cp_cfg[if_index].wki.ap_addr.ipv4),
            LOGON_BASE_HTTPS_PORT, mactoa(cp_cfg[if_index].wki.ap_addr.mac));
    if (rc)
        return rc;
#endif
    /*start add mark for logon process*/
    rc = cp_add_rule (IPTABLES, fname, "nat", NF_APPEND, "PREROUTING",
         "-p tcp -m mark --mark 0x%x/0x00ff -j DNAT --to-destination %s:%d",
          VAP_BASE_LOGON_PORT_MARK + if_index, "127.0.0.1",
          LOGON_BASE_HTTPS_PORT + if_index);
    if (rc)
         return rc;
    /*end add*/
    rc = cp_add_rule (IPTABLES, fname, "nat", NF_APPEND, "PREROUTING",
            "-p tcp -m mark --mark 0x%x/0x00ff -j DNAT --to-destination %s:%d",
            VAP_BASE_HTTP_PORT + if_index, "127.0.0.1",
            VAP_BASE_HTTP_NFQ_PORT + if_index);
    if (rc)
        return rc;
    rc = cp_add_rule (IPTABLES, fname, "nat", NF_APPEND, "PREROUTING",
            "-p tcp -m mark --mark 0x%x/0x00ff -j DNAT --to-destination %s:%d",
            VAP_BASE_HTTPS_PORT + if_index, "127.0.0.1",
            VAP_BASE_HTTPS_NFQ_PORT + if_index);
    if (rc)
        return rc;
    rc = cp_add_rule (IPTABLES, fname, "nat", NF_APPEND, "PREROUTING",
            "-p tcp -m mark --mark 0x%x/0x00ff -j DNAT --to-destination %s:%d",
            VAP_BASE_HTTP_NFQ_PORT_MARK + if_index, "127.0.0.1",
            VAP_BASE_HTTP_NFQ_PORT + if_index);
    if (rc)
        return rc;
    rc = cp_add_rule (IPTABLES, fname, "nat", NF_APPEND, "PREROUTING",
            "-p tcp -m mark --mark 0x%x/0x00ff -j DNAT --to-destination %s:%d",
            VAP_BASE_HTTPS_NFQ_PORT_MARK + if_index, "127.0.0.1",
            VAP_BASE_HTTPS_NFQ_PORT + if_index);
    if (rc)
        return rc;

    return 0;
}

int 
cp_init_dns_redir_rules (vap_if_index_t if_index)
{
    char fname[RULES_FILE_NAME_LEN];
    char cname[RULES_FILE_NAME_LEN];
    int rc = 0;

    snprintf (fname, RULES_FILE_NAME_LEN,
            "%s/dns.%s", CP_NF_RULE_PATH, gVapWlanMap[if_index]);

    snprintf(cname,RULES_FILE_NAME_LEN,"DNSFWALL_%s",gVapWlanMap[if_index]);

    rc = cp_add_rule(EBTABLES, fname, "broute",NF_APPEND,cname,
            "-i %s -p Ipv4 --ip-proto udp --ip-dport %d -j mark --mark-set 0x%d --mark-target ACCEPT", gVapWlanMap[if_index], CP_DNS_PORT_NO,CP_DNS_PORT + if_index);

    if(rc)
        return rc;

    return 0;
}

int
cp_init_general_rules (vap_if_index_t if_index)
{
    char fname[RULES_FILE_NAME_LEN];
    char cname[RULES_FILE_NAME_LEN];
	char cmd_str[CMD_STR_LEN];
	char rule_buf[CAPTIVE_PORTAL_CHAIN_RULE_LEN];
    int rc = 0, i ,s_f;
    FILE *fp = NULL;

	memset(cmd_str,0,CMD_STR_LEN);

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -I captive_portal -i %s -o eth2+ -j DROP",gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }	

	memset(cmd_str,0,CMD_STR_LEN);

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -I captive_portal -i eth2+ -o %s -j DROP",gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }	

    snprintf (fname, RULES_FILE_NAME_LEN,
            "%s/gen.%s", CP_NF_RULE_PATH, gVapWlanMap[if_index]);
    snprintf (cname, RULES_FILE_NAME_LEN,
            "GEN_%s", gVapWlanMap[if_index]);

    for (i = 0; ((rc == 0) && (gen_rules[i][0] != '\0')); i++)
    {
        rc = cp_add_rule (EBTABLES, fname, "broute", NF_APPEND, cname,
                "-p IPv4 -i %s %s",
                gVapWlanMap[if_index], gen_rules[i]);
    }

    rc = cp_add_rule (EBTABLES, fname, "broute", NF_APPEND, cname,"-p IPv6 -i %s -j DROP", gVapWlanMap[if_index]);
    if(rc)
        return rc;

    rc = cp_add_rule (EBTABLES, fname, "broute", NF_APPEND, cname,"-p IPv6 -i %s --ip6-proto ipv6-icmp -j ACCEPT", gVapWlanMap[if_index]);
    if(rc)
        return rc;

    rc = cp_add_rule (EBTABLES, fname, "broute", NF_APPEND, cname,"-p IPv6 -i %s --ip6-proto ipv6-icmp --ip6-icmp-type echo-request -j DROP", gVapWlanMap[if_index]);
    if(rc)
        return rc;

    return rc;
}

int cp_update_nf_rules()
{
    int i=1;
    char buffer[RULES_FILE_NAME_LEN + 20]={"\0"};
    for (i=0;i< VAP_END ;i++)
    {
        char fname[RULES_FILE_NAME_LEN];

        if (cp_cfg[i].enabled != TRUE) continue;

        snprintf (fname, RULES_FILE_NAME_LEN,
                "%s/firewall.%s", CP_NF_RULE_PATH, gVapWlanMap[i]);
        sprintf(buffer,"/bin/sh  %s",fname);
        CP_ERROR(1,"Executing comand for the removing the rule is %s ",buffer);
        system(buffer);

        remove(fname);
        if( cp_init_redir_rules(i)==FAILURE){
            CP_ERROR(1,"updating DNAT rules failed");
            return FAILURE;
        }
    }
}

int
cp_add_client_route (vap_if_index_t if_index, char *mac, char *ip_addr)
{
    char fname[CLIENT_RULES_FILE_NAME_LEN];
    char cmd_str[CMD_STR_LEN];
    FILE *fp = NULL;
    int rc = 0;

    snprintf(fname, CLIENT_RULES_FILE_NAME_LEN, "%s/route.%s.%s", CP_NF_RULE_PATH,
            mac, gVapWlanMap[if_index]);

    snprintf (cmd_str, CMD_STR_LEN, "route add -host %s dev %s", ip_addr, gVapWlanMap[if_index]);
    rc = system(cmd_str);
    if(rc) return rc;

    snprintf (cmd_str, CMD_STR_LEN, "route del -host %s dev %s", ip_addr, gVapWlanMap[if_index]);
    write_to_rules_file(fname, cmd_str);

    snprintf (cmd_str, CMD_STR_LEN, "arp -i %s -s %s %s", gVapWlanMap[if_index], ip_addr, mac);
    rc = system(cmd_str);
    if(rc) return rc;

    snprintf (cmd_str, CMD_STR_LEN, "arp -i %s -d %s", gVapWlanMap[if_index], ip_addr);
    write_to_rules_file(fname, cmd_str);

    return rc;
}

int
cp_add_client_bypass_rule (vap_if_index_t if_index, char *mac, int wallg_bypass)
{
    char fname[CLIENT_RULES_FILE_NAME_LEN];
    char cname[RULES_FILE_NAME_LEN];
    int rc;

    if (wallg_bypass == TRUE) {
        snprintf (cname, RULES_FILE_NAME_LEN,
                "CLIENTS_%s", gVapWlanMap[if_index]);
    } else {
        snprintf (cname, RULES_FILE_NAME_LEN,
                "FWALL_%s", gVapWlanMap[if_index]);
    }

    snprintf (fname, CLIENT_RULES_FILE_NAME_LEN, "%s/client.%s.%s", CP_NF_RULE_PATH,
            mac, gVapWlanMap[if_index]);
    rc = cp_add_rule (EBTABLES, fname, "broute", 1, cname,
            "-p IPv4 -i %s -s %s --ip-proto tcp --ip-dport %d -j mark --mark-set 0x%x --mark-target ACCEPT",
            gVapWlanMap[if_index], mac, HTTP_PORT,
            VAP_BASE_HTTP_PORT + if_index);
    if (rc) return rc;

    rc = cp_add_rule (EBTABLES, fname, "broute", 1, cname,
            "-p IPv4 -i %s -s %s --ip-proto tcp --ip-dport %d -j mark --mark-set 0x%x --mark-target ACCEPT",
            gVapWlanMap[if_index], mac, HTTPS_PORT,
            VAP_BASE_HTTPS_PORT + if_index);
    return rc;
}

static int cp_get_vlanConfig_from_uciFile (void)
{
    char uci_cmd_str[50] = {'\0'};
    char temp[SIZE] = {'\0'};
    int  netmask_arr[4] = {'\0'};
    int prefix_len=0;
    FILE *fp = NULL;
    char *ptr,*qtr,*str;
    int vlan_id,i,len,vlan_id_tmp;
    ulong vlan_addr;
   

    fp = popen("uci show network","r");
    if ( fp == NULL) {
        CP_ERROR(1, "Error in running %s command", uci_cmd_str);
        return FAILURE;
    }
    vlan_id = 0;

	for(i=0; i <VLAN_MAX; i++) {
		vlanipv4[i].ip[0] = 0;
	}

    while (fgets(temp, SIZE, fp) != NULL) {

        if ( (str= strstr(temp, "network.vlan")) ) { /* get interface status */
            	if( (ptr = strstr(str, ".ipaddr=")) ) {
			len = strlen(str)-strlen(ptr);//network.vlanx
			ptr = str + len;
			*ptr = 0x0;
			ptr = str + 12;//x
			vlan_id_tmp = atoi(ptr);
			ptr = str + len + 8;//ip address of vlanx
			vlan_id++;
			len = strlen(ptr) - 1;//minus '/n'
			strncpy(vlanipv4[vlan_id-1].ip,ptr,len);
			vlanipv4[vlan_id-1].ip[len] = 0;
			vlanipv4[vlan_id-1].vlan_id = vlan_id_tmp;
			CP_ERROR(1, "%s(%d)vlan_id=%d iplen = %d\n",
                        __FUNCTION__,__LINE__,vlanipv4[vlan_id-1].vlan_id, len);
                } else if( (qtr = strstr(str, ".netmask=")) ) {
			len = strlen(str) - strlen(qtr);//network.vlanx
			qtr = str + len;
			*qtr = 0x0;
			qtr = str + 12;
			vlan_id_tmp = atoi(qtr);
			qtr = str + len + 9;
			sscanf(qtr,"%d.%d.%d.%d",&netmask_arr[0],&netmask_arr[1],&netmask_arr[2],&netmask_arr[3]);
			prefix_len = 0;
			for(i=0;i<4;i++){
				if( netmask_arr[i] & 0x80 )
					prefix_len++;
				if( netmask_arr[i] & 0x40 )
					prefix_len++;
				if( netmask_arr[i] & 0x20 )
					prefix_len++;
				if( netmask_arr[i] & 0x10 )
					prefix_len++;
				if( netmask_arr[i] & 0x08 )
					prefix_len++;
				if( netmask_arr[i] & 0x04 )
					prefix_len++;
				if( netmask_arr[i] & 0x02 )
					prefix_len++;
				if( netmask_arr[i] & 0x01 )
					prefix_len++;
			}
			for(i=0; i <VLAN_MAX; i++) {
				if(vlanipv4[i].vlan_id == 0)
					break;
				if(vlanipv4[i].vlan_id == vlan_id_tmp) {
					vlanipv4[i].prefix_len = prefix_len;
					break;
				}
			}
			
			CP_ERROR(1, "%s(%d)vlanid=%d,qtr=%s,prefix_len=%d\n", 
			__FUNCTION__,__LINE__,vlan_id_tmp,qtr,prefix_len);
                }
        } 
        
    }
    pclose(fp);

    return SUCCESS;
}


int
cp_add_client_allow_rule (vap_if_index_t if_index, char *mac)
{
	char cname[RULES_FILE_NAME_LEN];
	char fname[CLIENT_RULES_FILE_NAME_LEN];
	int rc;
	int index;

	snprintf (cname, RULES_FILE_NAME_LEN,
            "AUTH_%s", gVapWlanMap[if_index]);
	snprintf (fname, CLIENT_RULES_FILE_NAME_LEN, "%s/client.%s.%s", CP_NF_RULE_PATH,
            mac, gVapWlanMap[if_index]);
	rc = cp_add_rule (EBTABLES, fname, "broute", 1, cname,
            "-i %s -s %s -j ACCEPT", gVapWlanMap[if_index], mac);
	if (cp_get_vlanConfig_from_uciFile()) {
		CP_ERROR (2, "vlan config failed FILE:%s-FUNCTION:%s-LINE:%d",
				 __FILE__, __func__, __LINE__);
		return FAILURE;
	}
	
	for (index=0; index < VLAN_MAX; index++) {

		if ( ( strlen(vlanipv4[index].ip) > 0 ) ) {
			rc = cp_add_rule (EBTABLES, fname, "broute", 1, cname,
			"-p ipv4 -i %s -s %s  --ip-dst %s/%d -j DROP", 
			gVapWlanMap[if_index], mac ,(vlanipv4[index].ip),(vlanipv4[index].prefix_len));
		}
	}

	rc = cp_add_rule (EBTABLES, fname, "broute", 1, cname,
            "-p ipv4 -i %s -s %s   --ip-dst %s  -j ACCEPT",
                        gVapWlanMap[if_index], mac ,inet_ntoa(cp_cfg[if_index].wki.ap_addr.ipv4));

	rc = cp_add_rule (EBTABLES, fname, "broute", 1, cname,
            "-p ipv4 -i %s -s %s --ip-proto tcp  --ip-dst %s --ip-dport %d -j DROP",
                        gVapWlanMap[if_index], mac ,inet_ntoa(cp_cfg[if_index].wki.ap_addr.ipv4),HTTPS_PORT);
	rc = cp_add_rule (EBTABLES, fname, "broute", 1, cname,
            "-p ipv4 -i %s -s %s --ip-proto tcp  --ip-dst %s --ip-dport %d -j DROP",
                        gVapWlanMap[if_index], mac ,inet_ntoa(cp_cfg[if_index].wki.ap_addr.ipv4),HTTP_PORT);

	rc = cp_add_rule (EBTABLES, fname, "broute", 1, cname,
            "-p IPv4 -s %s -i %s --ip-proto tcp --ip-dport 9300 -j mark --mark-set 0x%x --mark-target ACCEPT", mac ,gVapWlanMap[if_index],
            VAP_BASE_LOGON_PORT_MARK+if_index);
	
	rc = cp_add_rule (IPTABLES, fname, "filter", NF_APPEND, "captive_portal",
         "-p tcp --dport 443 -m mac --mac-source %s -j REJECT", mac);
	rc = cp_add_rule (IPTABLES, fname, "filter", NF_APPEND, "captive_portal",
         "-p tcp --dport 80 -m mac --mac-source %s -j REJECT", mac);
	rc = cp_add_rule (IPTABLES, fname, "filter", NF_APPEND, "captive_portal",
	"-p icmp --icmp-type echo-request -m mac --mac-source %s -j DROP", mac);

    rc = cp_add_rule (IP6TABLES, fname, "filter", NF_APPEND, "captive_portal",
         "-p tcp --dport 443 -m mac --mac-source %s -j REJECT", mac);
	rc = cp_add_rule (IP6TABLES, fname, "filter", NF_APPEND, "captive_portal",
         "-p tcp --dport 80 -m mac --mac-source %s -j REJECT", mac);
	rc = cp_add_rule (IP6TABLES, fname, "filter", NF_APPEND, "captive_portal",
	"-p icmpv6 --icmpv6-type echo-request -m mac --mac-source %s -j DROP", mac);

	return rc;
}

void
cp_flush_client_rules (vap_if_index_t if_index, char *mac)
{
	char fname[CLIENT_RULES_FILE_NAME_LEN];
	int rc;
	char command[CLIENT_RULES_FILE_NAME_LEN + 10];
	char cmd_str[CMD_STR_LEN];

	snprintf (fname, CLIENT_RULES_FILE_NAME_LEN, "%s/client.%s.%s", CP_NF_RULE_PATH,
            mac, gVapWlanMap[if_index]);
	snprintf(command,CLIENT_RULES_FILE_NAME_LEN + 10,"/bin/sh %s",fname);
	system(command);
	remove (fname);

	memset(cmd_str,0,sizeof(cmd_str));
	snprintf (cmd_str, CAPTIVE_PORTAL_CHAIN_RULE_LEN, "iptables  -w -D captive_portal -p tcp --dport 443 -m mac --mac-source %s -j REJECT",mac);
		
	rc = exec_rule (cmd_str);
	if (rc) {
			CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
			cmd_str);
	}

	memset(cmd_str,0,sizeof(cmd_str));
	snprintf (cmd_str, CAPTIVE_PORTAL_CHAIN_RULE_LEN, "iptables  -w -D captive_portal -p tcp --dport 80 -m mac --mac-source %s -j REJECT",mac);
		
	rc = exec_rule (cmd_str);
	if (rc) {
			CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
			cmd_str);
	}	

	memset(cmd_str,0,sizeof(cmd_str));
        snprintf (cmd_str, CAPTIVE_PORTAL_CHAIN_RULE_LEN, "iptables -w -D captive_portal -p icmp --icmp-type echo-request -m mac --mac-source %s -j DROP",mac);

	rc = exec_rule (cmd_str);
        if (rc) {
                        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                        cmd_str);
        }

	return;
}

void
cp_flush_client_route (vap_if_index_t if_index, char *mac)
{
    char fname[CLIENT_RULES_FILE_NAME_LEN];
    int rc;
    char command[CLIENT_RULES_FILE_NAME_LEN + 10];

    snprintf (fname, CLIENT_RULES_FILE_NAME_LEN, "%s/route.%s.%s", CP_NF_RULE_PATH,
            mac, gVapWlanMap[if_index]);
    snprintf(command,CLIENT_RULES_FILE_NAME_LEN + 10,"/bin/sh %s",fname);
    system(command);
    remove (fname);

    return;
}

void
cp_flush_vap_rules (vap_if_index_t if_index)
{
    char cname[RULES_FILE_NAME_LEN];
    static char cmd_str[CMD_STR_LEN];
    int rc;

    memset(cmd_str,0,sizeof(cmd_str));
    snprintf (cmd_str, CAPTIVE_PORTAL_CHAIN_RULE_LEN, "ebtables -D captive_portal -i %s -o eth2+ -j DROP",gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
	CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
    }
    memset(cmd_str,0,sizeof(cmd_str));
    snprintf (cmd_str, CAPTIVE_PORTAL_CHAIN_RULE_LEN, "ebtables -D captive_portal -i eth2+ -o %s -j DROP",gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
	CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
		cmd_str);
    }

    memset(cmd_str,0,sizeof(cmd_str));
    snprintf(cmd_str, CMD_STR_LEN,
            "for i in `ls %s/*\\.%s`; do /bin/sh $i; rm $i; done;",
            CP_NF_RULE_PATH, gVapWlanMap[if_index]);
    system(cmd_str);

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -D BROUTING -i %s -j AUTH_%s",
            gVapWlanMap[if_index], gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -X AUTH_%s", gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -D BROUTING -p IPv4 -i %s -j CLIENTS_%s",
            gVapWlanMap[if_index], gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -X CLIENTS_%s", gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -D BROUTING -p IPv4 -i %s -j DNSFWALL_%s",
            gVapWlanMap[if_index], gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -X DNSFWALL_%s", gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -D BROUTING -i %s -j GEN_%s",
            gVapWlanMap[if_index], gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -X GEN_%s", gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
    }

#if  0
    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -D BROUTING -p IPv4 -i %s -j WALLG_%s",
            gVapWlanMap[if_index], gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -X WALLG_%s", gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
    }
#endif
    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -D BROUTING -p IPv4 -i %s -j FWALL_%s",
            gVapWlanMap[if_index], gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -X FWALL_%s", gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -D BROUTING -p IPv4 -i %s -j SWALLG_%s",
            gVapWlanMap[if_index], gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -X SWALLG_%s", gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
    }
}

int
cp_init_chains (vap_if_index_t if_index)
{
    char cname[RULES_FILE_NAME_LEN];
    static char cmd_str[CMD_STR_LEN];
    int rc;

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -N AUTH_%s -P RETURN", gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -I BROUTING 1 -i %s -j AUTH_%s",
            gVapWlanMap[if_index], gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -N GEN_%s -P RETURN", gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -A BROUTING -i %s -j GEN_%s",
            gVapWlanMap[if_index], gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }

#if 0
    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -N WALLG_%s -P RETURN", gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -A BROUTING -p IPv4 -i %s -j WALLG_%s",
            gVapWlanMap[if_index], gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }
#endif

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -N CLIENTS_%s -P RETURN", gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -A BROUTING -p IPv4 -i %s -j CLIENTS_%s",
            gVapWlanMap[if_index], gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -N DNSFWALL_%s -P RETURN", gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -A BROUTING -p IPv4 -i %s -j DNSFWALL_%s",
            gVapWlanMap[if_index], gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -N SWALLG_%s -P RETURN", gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -A BROUTING -p IPv4 -i %s -j SWALLG_%s",
            gVapWlanMap[if_index], gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -N FWALL_%s -P DROP", gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }

    snprintf (cmd_str, CMD_STR_LEN,
            EBTABLES_CMD " -t broute -A BROUTING -p IPv4 -i %s -j FWALL_%s",
            gVapWlanMap[if_index], gVapWlanMap[if_index]);
    rc = exec_rule (cmd_str);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                cmd_str);
        return rc;
    }
    return SUCCESS;
}

int _cp_init_nf_rules (vap_if_index_t i)
{
    static int dns_started = 0;
    if (cp_init_chains (i) == FAILURE)
    {
        CP_ERROR (1,
                "Unable to write the general rule  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }
    else
    {
        CP_ERROR (1, "Initializing Chains success");
    }

    if (cp_init_general_rules (i) == FAILURE)
    {
        CP_ERROR (1,
                "Unable to write the general rule  FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }
    else
    {
        CP_ERROR (1, "Genrel Rules writting success");

    }
#if 0
    if (cp_init_walled_garden_rules (i) == FAILURE)
    {
        CP_ERROR (1,
                "Unable to write the walled garden rule into the file    FILE:%s-FUNCTION:%s-LINE:%d",
                __FILE__, __func__, __LINE__);
        return FAILURE;
    }
    else
    {
        CP_ERROR (1, "Walled garden rule writting success");
    }

    if (!dns_started) {
        dns_started = 1;
        dns_init();
    }
#endif
    if (cp_init_redir_rules (i) == FAILURE)
    {
        CP_ERROR (1, "Unable to init redir rule");
        return FAILURE;
    }
    else
    {
        CP_ERROR (1, "Redir rule init success");
    }
#if 0
    if(cp_init_dns_redir_rules(i) == FAILURE){
        CP_ERROR(1,"DNS rule init failed");
        return FAILURE;
    }
#endif
}

int
cp_init_nf_rules ()
{
    char buffer[128];
    snprintf (buffer, 128, "mkdir -p %s", CP_NF_RULE_PATH);
    system (buffer);
    int i,rc;
	
    memset(buffer,0,128);
    snprintf (buffer, 128,
            EBTABLES_CMD " -t filter -N captive_portal -P RETURN");
    rc = exec_rule (buffer);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                buffer);
        return rc;
    }

    memset(buffer,0,128);
    snprintf (buffer, 128,
            EBTABLES_CMD " -t filter -I FORWARD 1 -j captive_portal");
    rc = exec_rule (buffer);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                buffer);
        return rc;
    }	

    for (i = 0; i < VAP_END; i++)
    {
        if ( (cp_cfg[i].ssid_enabled == 1) && (cp_cfg[i].enabled == TRUE) ) 
        	_cp_init_nf_rules(i);
    }

}

void cp_deinit_rules ()
{
    int i,rc;
    char buffer[128];

    CP_ERROR(1, "removing all vap rules at %s:%d\n", __func__, __LINE__);

    for (i = 0; i < VAP_END; i++)
    {
        if (cp_cfg[i].enabled != TRUE) continue;
        cp_flush_vap_rules(i);
    }

	memset(buffer,0,128);
    snprintf (buffer, 128,
            EBTABLES_CMD " -t filter -D FORWARD -j captive_portal");   
    rc = exec_rule (buffer);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                buffer);
    }
	
	memset(buffer,0,128);
    snprintf (buffer, 128,
            EBTABLES_CMD " -X captive_portal");
    rc = exec_rule (buffer);
    if (rc) {
        CP_ERROR (1, "%s: Failed in executing the command \"%s\"", __func__,
                buffer);
    }
	
}

