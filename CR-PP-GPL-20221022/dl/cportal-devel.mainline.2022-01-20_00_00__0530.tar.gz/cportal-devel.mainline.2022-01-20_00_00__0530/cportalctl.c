/** @file cportalctl.c
    @brief Monitoring and control of cportal, client part
*/

#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <syslog.h>
#include <errno.h>

#include "cportalctl.h"


s_config config;

static void usage(void);
static void init_config(void);
static void parse_commandline(int, char **);
static int connect_to_server(const char[]);
static int send_request(int, const char[]);
static void cportalctl_action(const char[], const char[], const char[]);
static void cportalctl_print(const char[]);
static void cportalctl_status(void);
static void cportalctl_deauth(void);

/** @internal
 * @brief Print usage
 *
 * Prints usage, called when cportalctl is run with -h or with an unknown option
 */
static void
usage(void)
{
    printf("Usage: cportalctl command [arguments]\n");
    printf("\n");
    printf("commands:\n");
    printf("  status            View the status of cportal\n");
    printf("  deauth ip     Deauthenticate user with specified ip\n");
    printf("\n");
}

/** @internal
 *
 * Init default values in config struct
 */
static void
init_config(void)
{
    config.socket = strdup(DEFAULT_SOCK);
    config.command = CPORTALCTL_UNDEF;
}

/** @internal
 *
 * Uses getopt() to parse the command line and set configuration values
 */
void
parse_commandline(int argc, char **argv)
{
    extern int optind;
    int c;

    while (-1 != (c = getopt(argc, argv, "s:h"))) {
        switch(c) {
            case 'h':
                usage();
                exit(1);
                break;

            case 's':
                if (optarg) {
                    free(config.socket);
                    config.socket = strdup(optarg);
                }
                break;

            default:
                usage();
                exit(1);
                break;
        }
    }

    if ((argc - optind) <= 0) {
        usage();
        exit(1);
    }

    if (strcmp(*(argv + optind), "status") == 0) {
        config.command = CPORTALCTL_STATUS;
    } else if (strcmp(*(argv + optind), "simple") == 0) {
        config.command = CPORTALCTL_STATUS_SIMPLE;
    } else if (strcmp(*(argv + optind), "complex") == 0) {
        config.command = CPORTALCTL_STATUS_COMPLEX;
    } else if (strcmp(*(argv + optind), "deauth") == 0) {
        config.command = CPORTALCTL_DEAUTH;
        if ((argc - (optind + 1)) <= 0) {
            fprintf(stderr, "cportalctl: Error: You must specify an IP "
                    "or a Mac address to deauth\n");
            usage();
            exit(1);
        }
        config.param = strdup(*(argv + optind + 1));
    } else {
        fprintf(stderr, "cportalctl: Error: Invalid command \"%s\"\n", *(argv + optind));
        usage();
        exit(1);
    }
}

static int
connect_to_server(const char sock_name[])
{
    int sock;
    struct sockaddr_un	sa_un;

    /* Connect to socket */
    sock = socket(AF_UNIX, SOCK_STREAM, 0);
    memset(&sa_un, 0, sizeof(sa_un));
    sa_un.sun_family = AF_UNIX;
    strncpy(sa_un.sun_path, sock_name, (sizeof(sa_un.sun_path) - 1));

    if (connect(sock, (struct sockaddr *)&sa_un,
                strlen(sa_un.sun_path) + sizeof(sa_un.sun_family))) {
        fprintf(stderr, "cportalctl: cportal probably not started (Error: %s)\n", strerror(errno));
        exit(1);
    }

    return sock;
}

static int
send_request(int sock, const char request[])
{
    ssize_t	len, written;

    len = 0;
    while (len != strlen(request)) {
        written = write(sock, (request + len), strlen(request) - len);
        if (written == -1) {
            fprintf(stderr, "Write to cportal failed: %s\n",
                    strerror(errno));
            exit(1);
        }
        len += written;
    }

    return((int)len);
}

/* Perform a cportalctl action, with server response Yes or No.
 * Action given by cmd, followed by config.param.
 * Responses printed to stdout, as formatted by ifyes or ifno.
 * config.param interpolated in format with %s directive if desired.
 */
static void
cportalctl_action(const char cmd[], const char ifyes[], const char ifno[])
{
    int sock;
    char buffer[4096];
    char request[128];
    int len, rlen;

    sock = connect_to_server(config.socket);

    snprintf(request, sizeof(request)-strlen(CPORTALCTL_TERMINATOR),
            "%s %s", cmd, config.param);
    strcat(request, CPORTALCTL_TERMINATOR);

    len = send_request(sock, request);

    len = 0;
    memset(buffer, 0, sizeof(buffer));
    while ((len < sizeof(buffer)) && ((rlen = read(sock, (buffer + len),
                        (sizeof(buffer) - len))) > 0)) {
        len += rlen;
    }

    if(rlen<0) {
        fprintf(stderr, "cportalctl: Error reading socket: %s\n", strerror(errno));
    }

    if (strcmp(buffer, "Yes") == 0) {
        printf(ifyes, config.param);
    } else if (strcmp(buffer, "No") == 0) {
        printf(ifno, config.param);
    } else {
        fprintf(stderr, "cportalctl: Error: cportal sent an abnormal "
                "reply.\n");
    }

    shutdown(sock, 2);
    close(sock);
}

/* Perform a cportalctl action, printing to stdout the server response.
 *  Action given by cmd.
 */
static void
cportalctl_print(const char cmd[])
{
    int sock;
    char buffer[4096];
    char request[32];
    int len;

    sock = connect_to_server(config.socket);

    snprintf(request, sizeof(request)-strlen(CPORTALCTL_TERMINATOR), "%s", cmd);
    strcat(request, CPORTALCTL_TERMINATOR);

    len = send_request(sock, request);

    while ((len = read(sock, buffer, sizeof(buffer)-1)) > 0) {
        buffer[len] = '\0';
        printf("%s", buffer);
    }

    if(len<0) {
        fprintf(stderr, "cportalctl: Error reading socket: %s\n", strerror(errno));
    }

    shutdown(sock, 2);
    close(sock);
}

static void
cportalctl_status(void)
{
    cportalctl_print("status");
}

static void cportalctl_status_simple(void)
{
    cportalctl_print("simple");
}

static void cportalctl_status_complex(void)
{
    cportalctl_print("complex");
}

void
cportalctl_deauth(void)
{
    cportalctl_action("deauth",
            "Client %s deauthenticated.\n",
            "Client %s not found.\n");
}

int
main(int argc, char **argv)
{
    /* Init configuration */
    init_config();
    parse_commandline(argc, argv);

    switch(config.command) {
        case CPORTALCTL_STATUS:
            cportalctl_status();
            break;
        case CPORTALCTL_STATUS_SIMPLE:
            cportalctl_status_simple();
            break;
        case CPORTALCTL_STATUS_COMPLEX:
            cportalctl_status_complex();
            break;
        case CPORTALCTL_DEAUTH:
            cportalctl_deauth();
            break;
        default:
            fprintf(stderr, "Unknown opcode: %d\n", config.command);
            exit(1);
            break;
    }
    exit(0);
}
