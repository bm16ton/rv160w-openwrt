#include <security/pam_appl.h>
#include <security/pam_misc.h>
#include <stdio.h>
#include "cp_auth.h"
#include "cp_main.h"

struct conversation_data {
    /**
     * Password
     */
     char *password;

    /**
     * Connection name 
     */
     char *connName;
};
static int my_conv(int num_msg, const struct pam_message** msg,
        struct pam_response** resp, struct conversation_data *data);

static struct pam_conv conv = {
    my_conv,
    NULL
};

void print_result(char* function, int res);

/*
 * Authenticate a username/password using PAM
 */
bool authenticate(char *service, char *user, char *password, char *connName)
{
    pam_handle_t *pamh = NULL;
    static struct pam_conv conv;
    int ret;
    struct conversation_data data;

    data.password = password;
    data.connName = connName;
    conv.conv = (void*)my_conv;
    conv.appdata_ptr = (void *)&data;

    ret = pam_start(service, user, &conv, &pamh);
    if (ret != PAM_SUCCESS)
    {
        CP_ERROR(1, "cportal pam_start for '%s' failed: %s",
             user, pam_strerror(pamh, ret));
        return FALSE;
    }
    ret = pam_authenticate(pamh, 0);
    if (ret == PAM_SUCCESS)
    {
        ret = pam_acct_mgmt(pamh, 0);
        if (ret != PAM_SUCCESS)
        {
            CP_ERROR(1, "cportal pam_acct_mgmt for '%s' failed: %s",
                 user, pam_strerror(pamh, ret));
        }
    }
    else
    {
        CP_ERROR(1, "cportal pam_authenticate for '%s' failed: %s",
             user, pam_strerror(pamh, ret));
    }
    pam_end(pamh, ret);
    return ret == PAM_SUCCESS;
}

void print_result(char* function, int res)
{
    switch(res)
    {
        case PAM_ABORT :
            printf("\n%s returned - PAM_ABORT\n", function);
            break;
        case PAM_BAD_ITEM :
            printf("\n%s returned - PAM_BAD_ITEM\n", function);
            break;
        case PAM_BUF_ERR :
            printf("\n%s returned - PAM_BUF_ERR\n", function);
            break;
        case PAM_SUCCESS :
            printf("\n%s returned - PAM_SUCCESS\n", function);
            break;
            printf("\n SUCCESS \n");
        case PAM_SYSTEM_ERR :
            printf("\n%s returned - PAM_SYSTEM_ERR\n", function);
            break;
        case PAM_AUTH_ERR :
            printf("\n%s returned - PAM_AUTH_ERR\n", function);
            break;
        case PAM_CRED_INSUFFICIENT :
            printf("\n%s returned - PAM_CRED_INSUFFICIENT\n", function);
            break;
        case PAM_AUTHINFO_UNAVAIL :
            printf("\n%s returned - PAM_AUTH_INFO_UNAVAIL\n", function);
            break;
        case PAM_MAXTRIES :
            printf("\n%s returned - PAM_MAXTRIES\n", function);
            break;
        case PAM_USER_UNKNOWN :
            printf("\n%s returned - PAM_USER_UNKNOWN\n", function);
            break;
        default:
            printf("\n%s returned unknown 0x%x\n", function, res);
            break;
    }
}

#define PAM_AUTH_CONNECTION_NAME 0x2000
/**
 * PAM conv callback function
 */
static int my_conv(int num_msg, const struct pam_message **msg,
                     struct pam_response **resp, struct conversation_data *data)
{
    struct pam_response *response;

    if (num_msg != 1)
    {
        return PAM_CONV_ERR;
    }
    response = malloc(sizeof(struct pam_response));
    if (msg[0]->msg_style == PAM_AUTH_CONNECTION_NAME)
    {
        response->resp = strdup(data->connName);
        response->resp_retcode = 0;
        *resp = response;

    }
    else
    {
        response->resp = strdup(data->password);
        response->resp_retcode = 0;
        *resp = response;
    }
    return PAM_SUCCESS;
}
