#ifndef _CP_HTTPD_H_
#define _CP_HTTPD_H_  1
#include<sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include"capportald.h"
#include"cp_socket_init.h"


#define HTTP_SELECT_TIMEOUT_S 1
#define HTTP_SELECT_TIMEOUT_U 0

#endif
