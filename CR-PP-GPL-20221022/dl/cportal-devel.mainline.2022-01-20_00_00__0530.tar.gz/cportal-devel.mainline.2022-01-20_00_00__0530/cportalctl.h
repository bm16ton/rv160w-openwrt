/** @file cportalctl.h
  @brief cportal monitoring client
  */

#ifndef _CPORTALCTL_H_
#define _CPORTALCTL_H_

#define DEFAULT_SOCK	"/tmp/cportalctl.sock"

#define CPORTALCTL_TERMINATOR	"\r\n\r\n"

#define CPORTALCTL_UNDEF		0
#define CPORTALCTL_STATUS		1
#define CPORTALCTL_DEAUTH		2
#define CPORTALCTL_STATUS_SIMPLE		3
#define CPORTALCTL_STATUS_COMPLEX		4


typedef struct {
    char	*socket;
    int	command;
    char	*param;
} s_config;


#endif /* _CPORTALCTL_H_ */
