#include <stdio.h>
#include <ctype.h>
#include "cp_main.h"
#include "capportald.h"
#include "cp_util.h"
#include "cp_socket_init.h"
#include "cp_auth.h"
#include "cp_client_list.h"

int cp_redir_main (nw_addr_t * client, void *conn,int do_ssl,vap_if_index_t vap);
static int cp_redir_msg_init (redir_msg_t * msg, nw_addr_t * client,vap_if_index_t vap);
static int cp_redir_init_client (nw_addr_t * dclient, nw_addr_t * sclient);
static void cp_redir_msg_init_component (redir_msg_t * msg);
static void safe_free (redir_msg_t * msg);
static int cp_redir_url_response (void *conn,redir_msg_t * msg,int do_ssl,vap_if_index_t vap_index);



int cp_success_redir(nw_addr_t * cli,void *conn,int do_ssl,char *landing_url,int vap,int code)
{
    char *buffer, *body, *redir_url;
    int len, content_len;
    char ap_ip[IP_ADDR_STR_LEN+1];
    char client_ip[IP_ADDR_STR_LEN+1];
    char ap_mac[MAC_ADDR_STR_LEN+1];
    char client_mac[MAC_ADDR_STR_LEN+1];
    int redir_port;

    redir_port = LOGON_BASE_HTTPS_PORT;
    strncpy(ap_mac,mactoa(cp_cfg[vap].wki.ap_addr.mac),MAC_ADDR_STR_LEN);
    ap_mac[MAC_ADDR_STR_LEN] = '\0';
    strncpy(client_mac,mactoa(cli->mac),MAC_ADDR_STR_LEN);
    client_mac[MAC_ADDR_STR_LEN] = '\0';
    strncpy(ap_ip,inet_ntoa (cp_cfg[vap].wki.ap_addr.ipv4),IP_ADDR_STR_LEN);
    ap_ip[IP_ADDR_STR_LEN]='\0';
    strncpy(client_ip,inet_ntoa (cli->ipv4),IP_ADDR_STR_LEN);
    client_ip[IP_ADDR_STR_LEN]='\0';

	if( code == LOGIN_CODE ) {
		len = asprintf (&redir_url,
                    "%s?landing_url=%s&ap_ip=%s&ap_port=%d&ap_mac=%s&client_mac=%s&client_ip=%s&ssid=%s&",
                    cp_cfg[vap].info_url, landing_url ? landing_url : "https://www.google.com/",
					ap_ip, redir_port, ap_mac, client_mac,
					client_ip, cp_cfg[vap].wki.ssid
                    );
	} else if( code  == LOGOUT_CODE) {
		len = asprintf (&redir_url,
                    "%s&ap_ip=%s&ap_port=%d&ap_mac=%s&client_mac=%s&client_ip=%s&ssid=%s&",
                    landing_url,
					ap_ip, redir_port, ap_mac, client_mac,
					client_ip, cp_cfg[vap].wki.ssid
                    );
	} else if( code  == LOGIN_ERR_CODE ) {
		len = asprintf (&redir_url,
                    "%s&ap_ip=%s&ap_port=%d&ap_mac=%s&client_mac=%s&client_ip=%s&ssid=%s&resp=1&",
                    landing_url,
					ap_ip, redir_port, ap_mac, client_mac,
					client_ip, cp_cfg[vap].wki.ssid
                    );
	}		
	
    content_len = asprintf (&body,
            "<HTML><HEAD><meta http-equiv=\"content-type\" content=\"text/html;charset=utf-8\">\r\n"
            "<TITLE>302 Moved</TITLE></HEAD><BODY>\r\n"
            "<H1>302 Moved</H1>\r\n"
            "The document has moved\r\n"
            "<A HREF=\"%s\">here</A>.\r\n"
            "</BODY></HTML>\r\n\r\n",
            redir_url);
    if (content_len < 1) {
        CP_ERROR (1, "Content generate asprintf failed");
        return FAILURE;
    }


    len = asprintf (&buffer,
            "HTTP/1.1 302 Found\r\n"
            "Cache-Control: private\r\n"
            "Content-Type: text/html; charset=UTF-8\r\n"
            "Location: %s\r\n"
            "Content-Length: %d\r\n"
            "Connection: close\r\n\r\n"
            "%s",
            redir_url,
            content_len, body);
    free(body);
    printf ("Response URL:-    %s\n", buffer);
    len = cp_send(conn, buffer, len+1,do_ssl);
    if (len < 1)
    {
        free(buffer);
        CP_ERROR (1, "%s(): Response writting failed", __func__);
        return FAILURE;
    }
    else
    {
        CP_ERROR (1, "Response writting success");
    }
    free(buffer);

    return SUCCESS;
}

/* Converts an integer value to its hex character*/
char to_hex(char code) {
    static char hex[] = "0123456789abcdef";
    return hex[code & 15];
}

/* Returns a url-encoded version of str */
/* IMPORTANT: be sure to free() the returned string after use */
char *url_encode(char *str) {
    char *pstr = str, *buf = malloc(strlen(str) * 3 + 1), *pbuf = buf;
    while (*pstr) {
        if (isalnum(*pstr) || *pstr == '-' || *pstr == '_' || *pstr == '.' || *pstr == '~') 
            *pbuf++ = *pstr;
        else if (*pstr == ' ') 
            *pbuf++ = '+';
        else 
            *pbuf++ = '%', *pbuf++ = to_hex(*pstr >> 4), *pbuf++ = to_hex(*pstr & 15);
        pstr++;
    }
    *pbuf = '\0';
    return buf;
}

char *generate_auth_token (char *auth_token, char *client_mac, char *client_ip)
{
    int ip_index, j=0, mac_index = 0;
    int ip_len, mac_len;

    ip_len = strlen(client_ip);
    mac_len = strlen(client_mac);

    for(ip_index = 0, j=0; ip_index < ip_len && j < MAX_AUTHTOKEN_LEN ; ip_index++){	/* Loop for IP string. */
        if(mac_index < mac_len && client_ip[ip_index] & 0x01 ) {	/* Insert for MAC string elements*/
            if(client_mac[mac_index] == MAC_DELIMITER) {
                mac_index++;
            }
            auth_token[j++] = client_mac[mac_index++];
        }
        if(client_ip[ip_index] != IP_DELIMITER) {
            auth_token[j++] = client_ip[ip_index];
        }
    }

    for(ip_index = 0 ;mac_index < mac_len && j < MAX_AUTHTOKEN_LEN;mac_index++){
        if(ip_index < ip_len && client_mac[mac_index] & 0x01 ) {	/* Insert for MAC string elements*/
            if(client_ip[ip_index] == IP_DELIMITER) {
                ip_index++;
            }
            auth_token[j++] = client_ip[ip_index++];
        }
        if(client_mac[mac_index] != MAC_DELIMITER){
            auth_token[j++] = client_mac[mac_index];
        }
    }
    auth_token[j] = 0;
    return auth_token;
}

char *parse_server_ip(char *splash_url, char *server_ip)
{
    char splash_url_l[128];
    char *ptr = NULL;

    /* backup the original string */
    strcpy(splash_url_l, splash_url);

    ptr = strrchr(splash_url_l, '?');
    if(ptr == NULL) {
        return NULL;
    }

    ptr[0] = 0;	/* This is done to avoid being stuck with the extra / in the url */

    ptr = strrchr(splash_url_l,'/');
    if(ptr == NULL) {
        return NULL;
    }
    ptr++;	/* Skipping the '/' */
    strcpy(server_ip,ptr);
    return server_ip;
}

static int
cp_redir_url_response (void *conn, redir_msg_t * msg, int do_ssl, vap_if_index_t vap_index)
{
    char *buffer, *body, *redir_url;
    int len = 0, content_len = 0;
    char ap_ip[IP_ADDR_STR_LEN+1];
    char client_ip[IP_ADDR_STR_LEN+1];
    char ap_mac[MAC_ADDR_STR_LEN+1];
    char client_mac[MAC_ADDR_STR_LEN+1];
    int redir_port;
    static char buf[10000];
    char landing_url[1000];

    memset(landing_url,0,sizeof(landing_url));    
    strcpy(landing_url, "google.com");

    memset(buf,0,sizeof(buf));
    len = my_read(conn, do_ssl, buf, sizeof(buf)-1);
    if (len <= 0) {
        CP_ERROR (1, "Unable to read landing URL\n");
    } else if (strncmp(buf, "GET", 3) == 0) {
        char *tmp = NULL;
        char *buf_ptr = (char *) buf;
        printf ("Request:-    %s\n", buf);
        tmp = strstr(buf, "Host: ");
        if (tmp != NULL) {
            sscanf(tmp, "Host: %s", landing_url);

            buf_ptr += strlen("GET") + 1;
            if (tmp = index(buf_ptr, (int) ' ')) {
                *tmp = '\0';
                strncat(landing_url, buf_ptr, sizeof(landing_url));
            }
        } else {
            printf ("Unable to get host\n");
        }
    }
 
	redir_url = strstr(landing_url,"resp=1");
		
	if (NULL != redir_url) {
			*redir_url = 0x0;
	}

    redir_port = LOGON_BASE_HTTPS_PORT;

    strncpy(ap_mac,mactoa(msg->wki->ap_addr.mac),MAC_ADDR_STR_LEN);
    ap_mac[MAC_ADDR_STR_LEN] = '\0';
    strncpy(client_mac,mactoa(msg->client_addr->mac),MAC_ADDR_STR_LEN);
    client_mac[MAC_ADDR_STR_LEN] = '\0';
    strncpy(ap_ip,inet_ntoa (msg->wki->ap_addr.ipv4),IP_ADDR_STR_LEN);
    ap_ip[IP_ADDR_STR_LEN]='\0';
    strncpy(client_ip,inet_ntoa (msg->client_addr->ipv4),IP_ADDR_STR_LEN);
    client_ip[IP_ADDR_STR_LEN]='\0';

    switch(cp_cfg[vap_index].cloud_provider) {
        case CLOUD_PROVIDER_INTERNAL: /* Ineternel cloud support */
            len = asprintf (&redir_url,
                    "%s?landing_url=%s%s&ap_ip=%s&ap_port=%d&ap_mac=%s&client_mac=%s&client_ip=%s&ssid=%s&",
                    cp_cfg[vap_index].splash_url, do_ssl?"https://":"http://", landing_url,
                    ap_ip, redir_port, ap_mac, client_mac,
                    client_ip, msg->wki->ssid);

            break;
        default : /* this should not reach */
            break;
    }
    if (len < 1) {
        CP_ERROR (1, "Redir URL generate asprintf failed");
        return FAILURE;
    }

    content_len = asprintf (&body,
            "<HTML><HEAD><meta http-equiv=\"content-type\" content=\"text/html;charset=utf-8\">\r\n"
            "<TITLE>302 Moved</TITLE></HEAD><BODY>\r\n"
            "<H1>302 Moved</H1>\r\n"
            "The document has moved\r\n"
            "<A HREF=\"%s\">here</A>.\r\n"
            "</BODY></HTML>\r\n\r\n",
            redir_url);
    if (content_len < 1) {
        free(redir_url);
        CP_ERROR (1, "Content generate asprintf failed");
        return FAILURE;
    }

    len = asprintf (&buffer,
            "HTTP/1.1 302 Found\r\n"
            "Cache-Control: private\r\n"
            "Content-Type: text/html; charset=UTF-8\r\n"
            "Location: %s\r\n"
            "Content-Length: %d\r\n"
            "Connection: close\r\n\r\n"
            "%s",
            redir_url, content_len, body);
    free(redir_url);
    free(body);

    if (len < 1)
    {
        CP_ERROR (1, "URL generate asprintf failed");
        return FAILURE;
    }
    buffer[len] = '\0';

    len = cp_send(conn, buffer, len+1,do_ssl);
    if (len < 1)
    {
        free(buffer);
        CP_ERROR (1, "%s(): Response writting failed", __func__);
        return FAILURE;
    }
    else
    {
        CP_ERROR (1, "%s(): Response writting success", __func__);
    }
    free(buffer);
    return SUCCESS;
}

static void
safe_free (redir_msg_t * msg)
{
    free (msg->client_addr);
    return;
}

static void
cp_redir_msg_init_component (redir_msg_t * msg)
{
    msg->client_addr=(nw_addr_t *)safe_malloc(sizeof(nw_addr_t));

}

static int
cp_redir_init_client (nw_addr_t * dclient, nw_addr_t * sclient)
{
    safe_memcpy (dclient, sclient, sizeof (nw_addr_t));
    CP_ERROR (1, "REDIR client init successful");
    return SUCCESS;
}

static int
cp_redir_msg_init (redir_msg_t * msg, nw_addr_t * client, vap_if_index_t vap)
{
    cp_redir_msg_init_component (msg);
    CP_ERROR (1, "Redir msg init component success, msg = %p, client = %p", msg, client);
    msg->wki = &(cp_cfg[vap].wki);
    if (cp_redir_init_client (msg->client_addr, client) == FAILURE)
    {
        CP_ERROR (2, "client detail init failed");
        return FAILURE;
    }
    return SUCCESS;
}

int
cp_redir_main (nw_addr_t * client, void *conn,int do_ssl,vap_if_index_t vap)
{
    redir_msg_t msg;

    if (cp_redir_msg_init (&msg, client,vap) == FAILURE)
    {
        CP_ERROR (1, "%s - %d ,cp_redir msg init failed", __func__, __LINE__);
        safe_free (&msg);
        return FAILURE;
    }
    if (cp_redir_url_response (conn, &msg, do_ssl, vap) ==FAILURE)
    {
        CP_ERROR (1, "%s  - %d , CP_redir URL generate success", __func__,
                __LINE__);
        safe_free (&msg);
        return FAILURE;
    }
    safe_free (&msg);
    return SUCCESS;
}
