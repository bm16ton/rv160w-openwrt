#include "cp_debug.h"
#include <syslog.h>
#include <stdarg.h>

#ifdef CP_LOG_FILE
int
cp_log_file_init (void)
{
    int fd_log;
    printf ("Entering into the function: %s\n", __func__);
    fd_log = open (CP_LOG_FILE_NAME, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (fd_log == -1)
    {
        printf ("log file opening failed\n");
        return -1;
    }
    return fd_log;
}

void
cp_logger (char *buf)
{
    int len = 0;
    int fd_log=cp_log_file_init();
    len = write (fd_log, buf, strlen (buf) + 1);
    if (len < 1)
    {
        printf ("write failed\n");
        exit (0);
    }
    close(fd_log);
}
#endif

static char buffer[1024];

#ifdef CP_DEBUG_INFO
cp_info (int level, char *fmt, ...)
{
    va_list ap;
    va_start (ap, fmt);
    (void) vsnprintf (buffer, sizeof(buffer), fmt, ap);
    va_end (ap);
    fprintf (stderr, "%s\n", buffer);
    syslog (level, "%s", buffer);
    return;
}

#else
void
cp_info_empty (int level, char *fmt, ...)
{
    va_list ap;
    va_start (ap, fmt);
    vprintf (fmt, ap);
    va_end (ap);
    printf ("\n");
    return;
}
#endif
#ifdef CP_DEBUG
void
cp_error (int level, char *fmt,...)
{
    va_list ap;
    va_start (ap, fmt);
    (void) vsnprintf (buffer, sizeof(buffer), fmt, ap);
    va_end (ap);
    fprintf (stderr, "%s\n", buffer);
    syslog (level, "%s", buffer);
#ifndef CP_LOG_FILE
    cp_logger (buffer);
#endif
    return;
}
#else
void
cp_error_empty (int level, char *fmt,...)
{
    va_list ap;
    va_start (ap, fmt);
    vprintf (fmt, ap);
    va_end (ap);
    printf ("\n");
    return;
}
#endif

void
cp_syslog (int level, char *fmt, ...)
{
#if 0
    va_list ap;
    va_start (ap, fmt);
    vsyslog (level, fmt, ap);
    va_end (ap);
    return;
#endif 
	va_list args;
	char buf[1024];
	
	va_start(args, fmt);
	vsprintf(buf, fmt, args);
	/* don't do openlog or closelog, but put our name in to be friendly */
	syslog(level, "cportald: %s", buf);
	va_end(args);
}
