#!/bin/sh

cmm -c set rx interface wan bridge add da 1:1:1:1:1:1
