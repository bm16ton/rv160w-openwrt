#!/bin/sh

cmm -c set sa_query_timer enable
cmm -c set sa_query_timer disable
