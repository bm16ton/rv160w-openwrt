#!/bin/sh

cmm -c query route
#returns "ERROR: FPP IPV4 ROUTE table empty"

