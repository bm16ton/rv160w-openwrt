#!/bin/sh

cmm -c show socket sock_id 1
