#!/bin/sh

cmm -c set ff enable
cmm -c set ff disable
