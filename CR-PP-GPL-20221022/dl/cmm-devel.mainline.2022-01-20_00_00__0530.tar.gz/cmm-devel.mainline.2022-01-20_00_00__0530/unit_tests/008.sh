#!/bin/sh

cmm -c set rtp close ccn 1
