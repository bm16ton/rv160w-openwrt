#!/bin/sh

cmm -c set rx interface wan bridge remove da 1:1:1:1:1:1
