/*
 *
 *  Copyright (C) 2007 Mindspeed Technologies, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "cmm.h"
#include "fpp.h"
#include <ctype.h>
#include <limits.h>


void cmmSWQOSSetPrintHelp();

static char *print_array_list(char *buf, u_int32_t *array, int nbits)
{
	int i, first;
	*buf = '\0';
	for (i = 0; i < nbits; i++)
	{
		if (!bitarray_testbit(array, i))
			continue;
		if (*buf != '\0')
			strcat(buf, ",");
		first = i++;
		if (i == nbits || !bitarray_testbit(array, i))
			sprintf(buf + strlen(buf), "%d", first);
		else
		{
			for ( ; i < nbits; i++)
			{
				if (!bitarray_testbit(array, i))
					break;
			}
			sprintf(buf + strlen(buf), "%d-%d", first, i - 1);
		}
	}
	return buf;
}

int cmmSWQOSQueryProcess(char ** keywords, int tabStart, daemon_handle_t daemon_handle)
{
	int cpt = tabStart;
        int rcvBytes;
	int qnum, shapernum, schednum;
	int count;
        short rc;
	short reset_flag = 0;
        char rcvBuffer[256];
        char sndBuffer[256];
	char output_buf[512];
	char list_buf[512];
	char *alg;
        fpp_swqos_query_queue_cmd_t *pSWQOSQueryQueueCmd = ( fpp_swqos_query_queue_cmd_t *)sndBuffer;
        fpp_swqos_query_shaper_cmd_t *pSWQOSQueryShaperCmd = ( fpp_swqos_query_shaper_cmd_t *)sndBuffer;
        fpp_swqos_query_sched_cmd_t *pSWQOSQuerySchedCmd = ( fpp_swqos_query_sched_cmd_t *)sndBuffer;
        fpp_swqos_query_queue_rsp_t *pSWQOSQueryQueueRsp = ( fpp_swqos_query_queue_rsp_t *)rcvBuffer;
        fpp_swqos_query_shaper_rsp_t *pSWQOSQueryShaperRsp = ( fpp_swqos_query_shaper_rsp_t *)rcvBuffer;
        fpp_swqos_query_sched_rsp_t *pSWQOSQuerySchedRsp = ( fpp_swqos_query_sched_rsp_t *)rcvBuffer;

	if (keywords[cpt])
	{
		if(strcasecmp(keywords[cpt], "reset") == 0)
		{
			reset_flag = 1;
			cpt++;
		}
		if (keywords[cpt])
		{
			cmmSWQOSSetPrintHelp();
			return -1;
		}
	}

	cmm_print(DEBUG_STDOUT, "\nSWQOS Shaper details:\n");
	for (shapernum = 0, count = 0; shapernum < SWQOS_NUM_SHAPERS; shapernum++)
	{
		memset(sndBuffer, 0, sizeof(sndBuffer));
		memset(rcvBuffer, 0, sizeof(rcvBuffer));
		pSWQOSQueryShaperCmd->shaper = shapernum;
		rcvBytes = cmmSendToDaemon(daemon_handle, FPP_CMD_SWQOS_QUERY_SHAPER,
					pSWQOSQueryShaperCmd, sizeof(fpp_swqos_query_shaper_cmd_t), rcvBuffer);
		if (rcvBytes != sizeof(fpp_swqos_query_shaper_rsp_t))
		{
			rc = (rcvBytes < sizeof(unsigned short) ) ? 0 : *((unsigned short *) rcvBuffer);
			cmm_print(DEBUG_STDERR, "ERROR: Unexpected result returned from Query Shaper:%d, rcvBytes=%d\n", rc, rcvBytes);
			return CLI_OK;
		}
		print_array_list(list_buf, pSWQOSQueryShaperRsp->queue_array, SWQOS_NUM_QUEUES);
		if (list_buf[0] == '\0')
			continue;
		cmm_print(DEBUG_STDOUT, "Shaper %d:%s\n", shapernum, pSWQOSQueryShaperRsp->enable_flag ? "" : " [Disabled]");
		cmm_print(DEBUG_STDOUT, "    Rate (Kbps): %u, Bucket Size: %u, IFG: %u\n", pSWQOSQueryShaperRsp->rate, pSWQOSQueryShaperRsp->bucket_size, pSWQOSQueryShaperRsp->ifg);
		cmm_print(DEBUG_STDOUT, "    Queues: %s\n", list_buf);
		count++;
	}
	if (count == 0)
		cmm_print(DEBUG_STDOUT, "No Shapers Configured\n");

	cmm_print(DEBUG_STDOUT, "\nScheduler details:\n");
	for (schednum = 0, count = 0; schednum < SWQOS_NUM_SCHEDULERS; schednum++)
	{
		memset(sndBuffer, 0, sizeof(sndBuffer));
		memset(rcvBuffer, 0, sizeof(rcvBuffer));
		pSWQOSQuerySchedCmd->scheduler = schednum;
		rcvBytes = cmmSendToDaemon(daemon_handle, FPP_CMD_SWQOS_QUERY_SCHEDULER,
					pSWQOSQuerySchedCmd, sizeof(fpp_swqos_query_sched_cmd_t), rcvBuffer);
		if (rcvBytes != sizeof(fpp_swqos_query_sched_rsp_t))
		{
			rc = (rcvBytes < sizeof(unsigned short) ) ? 0 : *((unsigned short *) rcvBuffer);
			cmm_print(DEBUG_STDERR, "ERROR: Unexpected result returned from Query Scheduler:%d, rcvBytes=%d\n", rc, rcvBytes);
			return CLI_OK;
		}
		print_array_list(list_buf, pSWQOSQuerySchedRsp->queue_array, SWQOS_NUM_QUEUES);
		if (list_buf[0] == '\0')
			continue;
		cmm_print(DEBUG_STDOUT, "Scheduler %d:\n", schednum);
		switch (pSWQOSQuerySchedRsp->algo)
		{
			case 0: alg = "PQ"; break;
			case 1: alg = "CBWFQ"; break;
			case 2: alg = "DWRR"; break;
			case 3: alg = "RR"; break;
			default: alg = "??"; break;
		}
		cmm_print(DEBUG_STDOUT, "    Algorithm: %s\n", alg);
		cmm_print(DEBUG_STDOUT, "    Queues: %s\n", list_buf);
		count++;
	}
	if (count == 0)
		cmm_print(DEBUG_STDOUT, "No Schedulers Configured\n");

	cmm_print(DEBUG_STDOUT, "\nQueue details:\n");
	for (qnum = 0, count = 0; qnum < SWQOS_NUM_QUEUES; qnum++)
	{
		memset(sndBuffer, 0, sizeof(sndBuffer));
		memset(rcvBuffer, 0, sizeof(rcvBuffer));
		pSWQOSQueryQueueCmd->queue = qnum;
		pSWQOSQueryQueueCmd->reset_flag = reset_flag;
		rcvBytes = cmmSendToDaemon(daemon_handle, FPP_CMD_SWQOS_QUERY_QUEUE,
					pSWQOSQueryQueueCmd, sizeof(fpp_swqos_query_queue_cmd_t), rcvBuffer);
		if (rcvBytes != sizeof(fpp_swqos_query_queue_rsp_t))
		{
			rc = (rcvBytes < sizeof(unsigned short) ) ? 0 : *((unsigned short *) rcvBuffer);
			cmm_print(DEBUG_STDERR, "ERROR: Unexpected result returned from Query Queue:%d, rcvBytes=%d\n", rc, rcvBytes);
			return CLI_OK;
		}
		if (pSWQOSQueryQueueRsp->scheduler == 0xFF)
			continue;
		print_array_list(list_buf, pSWQOSQueryQueueRsp->shaper_array, SWQOS_NUM_SHAPERS);
		cmm_print(DEBUG_STDOUT, "Queue %d:\n", qnum);
		sprintf(output_buf, "    Scheduler: %u, Max Queue Depth: %u", pSWQOSQueryQueueRsp->scheduler, pSWQOSQueryQueueRsp->max_qdepth);
		if (pSWQOSQueryQueueRsp->qweight > 0)
			sprintf(output_buf + strlen(output_buf), ", Weight: %u", pSWQOSQueryQueueRsp->qweight);
		cmm_print(DEBUG_STDOUT, "%s\n", output_buf);
		if (list_buf[0])
			cmm_print(DEBUG_STDOUT, "    Shapers: %s\n", list_buf);
		if (pSWQOSQueryQueueRsp->packets_processed > 0 || pSWQOSQueryQueueRsp->packets_dropped > 0)
			cmm_print(DEBUG_STDOUT, "    Packets Processed: %u, Packets Dropped: %u\n", pSWQOSQueryQueueRsp->packets_processed, pSWQOSQueryQueueRsp->packets_dropped);
		count++;
	}
	if (count == 0)
		cmm_print(DEBUG_STDOUT, "No Queues Configured\n");

        return CLI_OK;
}


/************************************************************
 *
 *
 *
 ************************************************************/

#define QRANGE "{0-127}"

void cmmSWQOSSetPrintHelp()
{
	cmm_print(DEBUG_STDOUT, 
		  "Usage:\n"
		  "       set swqos reset\n"
                  "\n"
                  "       set swqos shaper {0-%d}\n"
                  "                       [on | off]\n"
                  "                       [rate {Kbps}]\n"
		  "                       [bucket_size {bits}]\n"
                  "                       [ifg {bytes}]\n"
                  "                       [reset]\n"
                  "                       [queue " QRANGE "] [queue " QRANGE "] ...\n"                  
                  "\n"
                  "       set swqos scheduler {0-%d}\n"
                  "                       [algorithm {pq | cbwfq | dwrr | rr}]\n"
                  "                       [reset]\n"
                  "                       [queue " QRANGE "] [queue " QRANGE "] ...\n"                  
                  "\n"
                  "       set swqos queue {0-%d}\n"
                  "                       [qdepth {depth}]\n"
                  "                       [qweight {weight}]\n"
                  "\n"
                  "       query swqos [reset]\n"
                  "\n",
	          SWQOS_NUM_SHAPERS - 1, SWQOS_NUM_SCHEDULERS - 1, SWQOS_NUM_QUEUES - 1);
}

/************************************************************
 *
 *
 *
 ************************************************************/
int cmmSWQOSSetProcess(char ** keywords, int tabStart, daemon_handle_t daemon_handle)
{
	int cpt = tabStart;
	u_int32_t val1, val2;
	unsigned int cmdToSend = 0; /* bits field*/
	int i;
	char rcvBuffer[256];

	fpp_swqos_reset_cmd_t resetCmd;
	fpp_swqos_config_shaper_cmd_t configShaperCmd;
	fpp_swqos_config_scheduler_cmd_t configSchedulerCmd;
	fpp_swqos_config_queue_cmd_t configQueueCmd;
    
	memset(&resetCmd, 0, sizeof(resetCmd));
	memset(&configShaperCmd, 0, sizeof(configShaperCmd));
	memset(&configSchedulerCmd, 0, sizeof(configSchedulerCmd));
	memset(&configQueueCmd, 0, sizeof(configQueueCmd));

	if(!keywords[cpt])
		goto help;

	if(strcasecmp(keywords[cpt], "reset") == 0)
	{
		if(keywords[++cpt])
			goto help;

		cmdToSend |= CMD_BIT(FPP_CMD_SWQOS_RESET);	
	}
	else if(strcasecmp(keywords[cpt], "shaper") == 0)
	{
		if(!keywords[++cpt])
			goto help;

		if (parse_value(keywords[cpt], &val1, 0, SWQOS_NUM_SHAPERS - 1) < 0)
		{
			cmm_print(DEBUG_ERROR, "ERROR: Invalid shaper number: %s\n", keywords[cpt]);
			goto help;
		}
		configShaperCmd.shaper = val1;
		
		if(!keywords[++cpt])
			goto help;

		cmdToSend |= CMD_BIT(FPP_CMD_SWQOS_CONFIG_SHAPER);

		configShaperCmd.ifg = 0xFF;
		configShaperCmd.rate = 0xFFFFFFFF;
		configShaperCmd.bucket_size = 0xFFFFFFFF;

		while (keywords[cpt] != NULL)
		{
			if(strcasecmp(keywords[cpt], "on") == 0)
			{
				configShaperCmd.enable_flag = 1;
			}
			else if(strcasecmp(keywords[cpt], "off") == 0)
			{
				configShaperCmd.enable_flag = 2;
			}
			else if(strcasecmp(keywords[cpt], "ifg") == 0)
			{
				if(!keywords[++cpt])
					goto help;
				if (parse_value(keywords[cpt], &val1, 0, 254) < 0)
				{
					cmm_print(DEBUG_ERROR, "ERROR: ifg must be a number between 0 and 254\n");
					goto help;
				}
				configShaperCmd.ifg = val1;
			}
			else if(strcasecmp(keywords[cpt], "rate") == 0)
			{
				if(!keywords[++cpt])
					goto help;

				if (parse_value(keywords[cpt], &val1, 8, ULONG_MAX) < 0)
                                {
                                        cmm_print(DEBUG_ERROR, "ERROR: invalid rate value\n");
                                        goto help;
                                }
				configShaperCmd.rate = val1;
			}
			else if(strcasecmp(keywords[cpt], "bucket_size") == 0)
			{
				if(!keywords[++cpt])
					goto help;

				if (parse_value(keywords[cpt], &val1, 0, ULONG_MAX) < 0)
                                {
                                        cmm_print(DEBUG_ERROR, "ERROR: invalid bucket_size value\n");
                                        goto help;
                                }
				configShaperCmd.bucket_size = val1;
			}
			else if(strcasecmp(keywords[cpt], "reset") == 0)
			{
				configShaperCmd.reset_flag = 1;
			}
			else if(strcasecmp(keywords[cpt], "queue") == 0)
			{
				if(!keywords[++cpt])
					goto help;

				if (parse_range(keywords[cpt], &val1, &val2, 0, SWQOS_NUM_QUEUES - 1) < 0)
				{
					cmm_print(DEBUG_ERROR, "ERROR: Invalid queue list: %s\n", keywords[cpt]);
					goto help;
				}
				for (i = val1; i <= val2; i++)
					bitarray_setbit(configShaperCmd.queue_array, i);
			}
			else
				goto keyword_error;

			cpt++;
		}
	}
	else if(strcasecmp(keywords[cpt], "scheduler") == 0)
	{
		if(!keywords[++cpt])
			goto help;

		if (parse_value(keywords[cpt], &val1, 0, SWQOS_NUM_SCHEDULERS - 1) < 0)
		{
			cmm_print(DEBUG_ERROR, "ERROR: Invalid scheduler number: %s\n", keywords[cpt]);
			goto help;
		}
		configSchedulerCmd.scheduler = val1;
		
		if(!keywords[++cpt])
			goto help;

		cmdToSend |= CMD_BIT(FPP_CMD_SWQOS_CONFIG_SCHEDULER);

		configSchedulerCmd.algo = 0xFF;

		while (keywords[cpt] != NULL)
		{
			if(strcasecmp(keywords[cpt], "algorithm") == 0)
			{
				if(!keywords[++cpt])
					goto help;

				if(strcasecmp(keywords[cpt], "pq") == 0)
				{
					configSchedulerCmd.algo = 0;
				}
				else if (strcasecmp(keywords[cpt], "cbwfq") == 0)
				{
					configSchedulerCmd.algo = 1;
				}
				else if (strcasecmp(keywords[cpt], "dwrr") == 0)
				{
					configSchedulerCmd.algo = 2;
				}
				else if (strcasecmp(keywords[cpt], "rr") == 0)
				{
					configSchedulerCmd.algo = 3;
				}
				else
					goto keyword_error;
			}			
			else if(strcasecmp(keywords[cpt], "reset") == 0)
			{
				configSchedulerCmd.reset_flag = 1;
			}
			else if(strcasecmp(keywords[cpt], "queue") == 0)
			{
				if(!keywords[++cpt])
					goto help;

				if (parse_range(keywords[cpt], &val1, &val2, 0, SWQOS_NUM_QUEUES - 1) < 0)
				{
					cmm_print(DEBUG_ERROR, "ERROR: Invalid queue list: %s\n", keywords[cpt]);
					goto help;
				}
				for (i = val1; i <= val2; i++)
					bitarray_setbit(configSchedulerCmd.queue_array, i);
			}
			else
				goto keyword_error;

			cpt++;
		}
	}

	else if(strcasecmp(keywords[cpt], "queue") == 0)
	{
		if(!keywords[++cpt])
			goto help;

		if (parse_value(keywords[cpt], &val1, 0, SWQOS_NUM_QUEUES - 1) < 0)
		{
			cmm_print(DEBUG_ERROR, "ERROR: Invalid queue number: %s\n", keywords[cpt]);
			goto help;
		}
		configQueueCmd.queue = val1;
		
		if(!keywords[++cpt])
			goto help;

		cmdToSend |= CMD_BIT(FPP_CMD_SWQOS_CONFIG_QUEUE);

		configQueueCmd.qweight = 0xFFFF;
		configQueueCmd.max_qdepth = 0xFFFF;

		while (keywords[cpt] != NULL)
		{
			if(strcasecmp(keywords[cpt], "qweight") == 0)
			{
				if(!keywords[++cpt])
					goto help;

				if (parse_value(keywords[cpt], &val1, 1, 0xFFFE) < 0)
                                {
                                        cmm_print(DEBUG_ERROR, "ERROR: invalid weight value\n");
                                        goto help;
                                }
				configQueueCmd.qweight = val1;
			}
			else if(strcasecmp(keywords[cpt], "qdepth") == 0)
			{
				if(!keywords[++cpt])
					goto help;

				if (parse_value(keywords[cpt], &val1, 16, 1023) < 0)
                                {
                                        cmm_print(DEBUG_ERROR, "ERROR: invalid qdepth value\n");
                                        goto help;
                                }
				configQueueCmd.max_qdepth = val1;
			}
			else
				goto keyword_error;

			cpt++;
		}
	}

	else
		goto keyword_error;

	/*
	 * Parsing have been performed
	 * Now send the right commands
	 */

	if(TEST_CMD_BIT(cmdToSend, FPP_CMD_SWQOS_RESET))
	{
		// Send CMD_SWQOS_RESET command
		if(cmmSendToDaemon(daemon_handle, FPP_CMD_SWQOS_RESET, &resetCmd, sizeof(resetCmd), &rcvBuffer) == 2)
		{
			if ( ((unsigned short *)rcvBuffer)[0] != 0)
				cmm_print(DEBUG_STDERR, "Error %d received from FPP for CMD_SWQOS_RESET\n", ((unsigned short *)rcvBuffer)[0]);
		}
	}
	
	if(TEST_CMD_BIT(cmdToSend, FPP_CMD_SWQOS_CONFIG_SHAPER))
	{
		// Send CMD_SWQOS_CONFIG_SHAPER command
		if(cmmSendToDaemon(daemon_handle, FPP_CMD_SWQOS_CONFIG_SHAPER, &configShaperCmd, sizeof(configShaperCmd), &rcvBuffer) == 2)
		{
			if (  (((unsigned short*)rcvBuffer)[0]) != 0)
				cmm_print(DEBUG_STDERR, "Error %d received from FPP for CMD_SWQOS_CONFIG_SHAPER\n", ((unsigned short*)rcvBuffer)[0]);
		}
	}

	if(TEST_CMD_BIT(cmdToSend, FPP_CMD_SWQOS_CONFIG_SCHEDULER))
	{
		// Send CMD_SWQOS_CONFIG_SCHEDULER command
		if(cmmSendToDaemon(daemon_handle, FPP_CMD_SWQOS_CONFIG_SCHEDULER, &configSchedulerCmd, sizeof(configSchedulerCmd), &rcvBuffer) == 2)
		{
			if (  (((unsigned short*)rcvBuffer)[0]) != 0)
				cmm_print(DEBUG_STDERR, "Error %d received from FPP for CMD_SWQOS_CONFIG_SCHEDULER\n", ((unsigned short*)rcvBuffer)[0]);
		}
	}

	if(TEST_CMD_BIT(cmdToSend, FPP_CMD_SWQOS_CONFIG_QUEUE))
	{
		// Send CMD_SWQOS_CONFIG_QUEUE command
		if(cmmSendToDaemon(daemon_handle, FPP_CMD_SWQOS_CONFIG_QUEUE, &configQueueCmd, sizeof(configQueueCmd), &rcvBuffer) == 2)
		{
			if (  (((unsigned short*)rcvBuffer)[0]) != 0)
				cmm_print(DEBUG_STDERR, "Error %d received from FPP for CMD_SWQOS_CONFIG_QUEUE\n", ((unsigned short*)rcvBuffer)[0]);
		}
	}


	return 0;

keyword_error:
	cmm_print(DEBUG_ERROR, "ERROR: Unknown keyword %s\n", keywords[cpt]);

help:
	cmmSWQOSSetPrintHelp();
	return -1;
}


