/* Auto-generated file. Do not edit tag_rv34x_v1.0.03.26 */
#ifndef VERSION_H
#define VERSION_H

#define CMM_VERSION "tag_rv34x_v1.0.03.26"

#endif /* VERSION_H */
