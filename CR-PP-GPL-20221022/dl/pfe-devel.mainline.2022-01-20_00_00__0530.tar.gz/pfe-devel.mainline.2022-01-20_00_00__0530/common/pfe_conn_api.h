/*
 *
 *  Copyright (C) 2007 Freescale Semiconductor, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _PFE_CONN_API_H_
#define _PFE_CONN_API_H_

#ifdef CFG_FLOW_STATS
typedef struct  _tCtStats{
	U8	ip_family;
	U8	flag; /* added by cust  0: alive, 1: will be removed */
	U16	Protocol;  

	union {
		struct {
			U32	Saddr;                  /*Source IPv4 address*/
			U32	Daddr;                  /*Destination IPv4 address*/
		};
		struct {
			U32	Saddr_v6[4];                  /*Source IPv6 address*/
			U32	Daddr_v6[4];                  /*Destination IPv6 address*/
		};
	};

	U16	Sport;                  /*Source Port*/
	U16	Dport;                  /*Destination Port*/
	U32	TotalPackets;
	U64	TotalBytes;
}CtStats, *PCtStats;
int register_del_conn_indication_cb(void (*del_conn_cb)(PCtStats,PCtStats));
int deregister_del_conn_indication_cb(void);

#endif /* CFG_FLOW_STATS */
#endif /* _PFE_CONN_API_H_ */
