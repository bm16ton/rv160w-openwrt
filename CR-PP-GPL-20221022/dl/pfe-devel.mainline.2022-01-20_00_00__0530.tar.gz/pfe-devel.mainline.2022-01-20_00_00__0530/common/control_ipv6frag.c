/*
 *  Copyright (c) 2011, 2014 Freescale Semiconductor, Inc.
 *
 *  THIS FILE IS CONFIDENTIAL.
 *
 *  AUTHORIZED USE IS GOVERNED BY CONFIDENTIALITY AND LICENSE AGREEMENTS WITH FREESCALE SEMICONDUCTOR, INC.
 *
 *  UNAUTHORIZED COPIES AND USE ARE STRICTLY PROHIBITED AND MAY RESULT IN CRIMINAL AND/OR CIVIL PROSECUTION.
 */


#include "Module_ipv6frag.h"
#include "fe.h"

#if defined(COMCERTO_2000_UTIL)
static TIMER_ENTRY ipv6_frag_timer;
#endif

#if defined(COMCERTO_2000_CONTROL) || !defined(COMCERTO_2000)
extern struct ip_frag_ctrl ipv6_frag_ctrl;
int IPv6_HandleIP_Set_FragTimeout(U16 *p, U16 Length)
{
	FragTimeoutCommand FragCmd;
	int rc = NO_ERR;

	// Check length
	if (Length != sizeof(FragTimeoutCommand))
		return ERR_WRONG_COMMAND_SIZE;

	// Ensure alignment
	SFL_memcpy((U8*)&FragCmd, (U8*)p, sizeof(FragTimeoutCommand));

#if !defined(COMCERTO_2000)
	ipv6_frag_timeout = FragCmd.timeout; // in ms
	ipv6_frag_expirydrop = FragCmd.mode;
#else
	ipv6_frag_ctrl.timeout = cpu_to_be16(FragCmd.timeout);
	ipv6_frag_ctrl.expire_drop = cpu_to_be16(FragCmd.mode);
	pe_dmem_memcpy_to32(UTIL_ID, virt_to_util_dmem(&ipv6_frag_ctrl), &ipv6_frag_ctrl, sizeof(ipv6_frag_ctrl));
#endif

	return rc;
}
#else

void ipv6_frag_init(void)
{

	SFL_defpart(&frag6Part, (void*)Frag6Storage, sizeof(FragIP6), NUM_FRAG6_Q);

	/* module entry point and channels registration */
	set_event_handler(EVENT_FRAG6, M_ipv6_frag_entry);
#if !defined(COMCERTO_2000)
	set_cmd_handler(EVENT_FRAG6, NULL);
#endif

	timer_init(&ipv6_frag_timer, M_ipv6_frag_timer);
	timer_add(&ipv6_frag_timer, IP_FRAG_TIMER_INTERVAL);
}
#endif
