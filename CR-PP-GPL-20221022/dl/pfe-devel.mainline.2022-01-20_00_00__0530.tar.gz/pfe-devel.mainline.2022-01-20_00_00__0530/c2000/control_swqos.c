/*
 *  Copyright (c) 2011, 2014 Freescale Semiconductor, Inc.
 *
 *  THIS FILE IS CONFIDENTIAL.
 *
 *  AUTHORIZED USE IS GOVERNED BY CONFIDENTIALITY AND LICENSE AGREEMENTS WITH FREESCALE SEMICONDUCTOR, INC.
 *
 *  UNAUTHORIZED COPIES AND USE ARE STRICTLY PROHIBITED AND MAY RESULT IN CRIMINAL AND/OR CIVIL PROSECUTION.
 */

#include "config.h"
#if defined(CFG_SWQOS)

#include "fpp.h"
#include "modules.h"
#include "channels.h"
#include "events.h"
#include "module_tx.h"
#include "system.h"
#include "fpart.h"
#include "fpool.h"
#include "fe.h"
#include "math.h"
#include "module_swqos.h"
#include "module_hidrv.h"

#include <linux/kernel.h>
#include <linux/interrupt.h>
#include <linux/dma-mapping.h>
#include <linux/dmapool.h>
#include <linux/sched.h>
#include <linux/module.h>
#include <linux/list.h>
#include <linux/kthread.h>
#include <linux/hrtimer.h>
#include <linux/slab.h>

#include <asm/io.h>
#include <asm/irq.h>

SWQOS_context swcontext;

SWQOS_MTD swqos_mtd_table[SWQOS_MAX_MTD];
PSWQOS_MTD swqos_mtd_freelist;

volatile u32 swqos_timer_tickcount;
volatile u32 swqos_process_tickcount;

struct hrtimer swqos_timer_struct;
static ktime_t swqos_timer_interval;

PSWQOS_MTD SWQOS_mtd_alloc(void);
void SWQOS_mtd_free(PSWQOS_MTD mtd);
int SWQOS_rx_process(int budget);
int SWQOS_tx_process(int budget);
static void SWQOS_shaper(PSWQOS_context pcontext, PSWQOS_ShaperDesc pshaper, int packet_length);
static PSWQOS_MTD SWQOS_dequeue(PSWQOS_context pcontext, int qnum);
void SWQOS_tx_congestion_discard(struct tSWQOS_context *pcontext);
PSWQOS_MTD SWQOS_get_data(PSWQOS_context pcontext);
void SWQOS_shaper_handler(void);

/****************************************************************/

extern struct pfe_hif_nocpy *hif_nocpy;

//#define SWQOS_loopback

int SWQOS_process(int budget)
{
	int work_done = 0;

	// if timer expired, run shaper handler
	while (swqos_timer_tickcount != swqos_process_tickcount)
	{
		++swqos_process_tickcount;
		SWQOS_shaper_handler();
	}

	// loop processing Rx packets, up to budget
	work_done = SWQOS_rx_process(budget);

	// loop processing Tx packets
	if (SWQOS_tx_process(budget) == 0)
	{
		work_done = budget;
		//DPRINT("more work for tx\n");
	}

	return work_done;
}

static int timer_is_running;
void SWQOS_start_timer(void)
{
	//ENTER();
	if (timer_is_running)
		return;
	swqos_timer_tickcount = swqos_process_tickcount = 0;
	swqos_timer_interval = ktime_set(0, 1 * NSEC_PER_MSEC);  // set up 1 msec timer
	hrtimer_start(&swqos_timer_struct, swqos_timer_interval, HRTIMER_MODE_REL);
	timer_is_running = 1;
}

void SWQOS_stop_timer(void)
{
	//ENTER();
	if (!timer_is_running)
		return;
	hrtimer_cancel(&swqos_timer_struct);
	timer_is_running = 0;
	swqos_timer_tickcount = swqos_process_tickcount = 0;
}

enum hrtimer_restart SWQOS_timer_callback(struct hrtimer *timer)
{
	ktime_t now;
	now = hrtimer_cb_get_time(timer);
	hrtimer_forward(timer, now, swqos_timer_interval);
	++swqos_timer_tickcount;
	SWQOS_schedule();
	return HRTIMER_RESTART;
}

void SWQOS_timer_init(void)
{
	//ENTER();
#ifdef SWQOS_loopback
	DPRINT("running in loopback mode\n");
#endif
	hrtimer_init(&swqos_timer_struct, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
	swqos_timer_struct.function = SWQOS_timer_callback;
}


PSWQOS_MTD SWQOS_mtd_alloc(void)
{
	PSWQOS_MTD this_mtd;
	this_mtd = swqos_mtd_freelist;
	if (this_mtd)
		swqos_mtd_freelist = this_mtd->next;
	else
		DPRINT("no mtd structures available\n");
	return this_mtd;
}

void SWQOS_mtd_free(PSWQOS_MTD mtd)
{
	mtd->next = swqos_mtd_freelist;
	swqos_mtd_freelist = mtd;
}


static void SWQOS_free_packet(PSWQOS_MTD pmeta)
{
	PSWQOS_context pcontext;
	u32 physaddr = (u32)DDR_VIRT_TO_PHYS(pmeta->data);
	//DPRINT("freeing packet 0x%x\n", physaddr);
	pfe_bmu_free_buff(BMU2_BASE_ADDR, physaddr);
	SWQOS_mtd_free(pmeta);
	pcontext = SWQOS_GET_CONTEXT();
	pcontext->total_packets_dropped++;
	pcontext->packets_dropped[pmeta->queue]++;
}

static void SWQOS_head_drop(struct tSWQOS_context *pcontext, int qnum)
{
	PSWQOS_QDesc pq;
	PSWQOS_MTD pmeta;
	pq = &pcontext->q[qnum];
	pmeta = SWQOS_dequeue(pcontext, qnum);
	if (pmeta)
		SWQOS_free_packet(pmeta);
	else
		DPRINT("NULL returned from SWQOS_dequeue\n");
}


// SWQOS_rx_process
//
// This function is the receive handler for SWQOS.  It is called by the SWQOS tasklet to handle
// the reading of packets from the HIF-NOCPY interface.

int SWQOS_rx_process(int budget)
{
	int work_done = 0;
	int qnum;
	int shapernum;
	PSWQOS_context pcontext;
	PSWQOS_MTD pmeta;
	PSWQOS_QDesc pq;
	PSWQOS_ShaperDesc pshaper;

	//ENTER();
	pcontext = SWQOS_GET_CONTEXT();

	// loop here getting packets from HIF_NOCPY interface
	do
	{
		pmeta = SWQOS_mtd_alloc();
		if (!pmeta)
		{
			DPRINT("unable to alloc mtd\n");
			return budget;
		}
		if (!pfe_hif_nocpy_rx_pkt(pmeta))
		{
			SWQOS_mtd_free(pmeta);
			break;
		}
		work_done++;
		qnum = pmeta->queue = pmeta->queue & SW_QUEUE_MASK;
		pq = &pcontext->q[qnum];

		// drop packet if no scheduler assigned to it
		if (pq->sched_num == 0xFF)
		{
			//DPRINT("packet received on queue %d with no scheduler\n", qnum);
			SWQOS_free_packet(pmeta);
			continue;
		}

		// enqueue the packet onto the output queue, and bump the current_qdepth counter
		if (pq->current_qdepth++ != 0) {
			// queue wasn't empty, add to tail
			pq->tail->next = pmeta;
		}
		else {
			// queue was empty, set head and tail
			pq->head = pmeta;			// (tail gets set below)
			pq->init_flag = TRUE;			// set flag that first packet was added
			bitlist_setbit(pcontext->active_queues, qnum);
			pq->ready_flag = TRUE;
			bitlist_for_each(pq->shaperlist, shapernum)
			{
				pshaper = &pcontext->shaper[shapernum];
				bitlist_setbit(pshaper->active_queues, qnum);
				if (pshaper->enable_flag && pshaper->tokens_available <= 0)
					pq->ready_flag = FALSE;
			}
			if (pq->ready_flag)
			{
				PSWQOS_SchedDesc psched = &pcontext->sched[pq->sched_num];
				bitlist_setbit(psched->ready_queues, qnum);
				bitlist_setbit(pcontext->ready_schedulers, pq->sched_num);
			}
		}
		pq->tail = pmeta;
		pcontext->num_packets_queued++;
		//DPRINT("pmeta=%x, head=%x, tail=%x, qnum=%d, current_qdepth=%d, pktptr=%x, ready_flag=%d\n", (u32)pmeta, (u32)pq->head, (u32)pq->tail, qnum, pq->current_qdepth, (u32)pmeta->data, pq->ready_flag);
	} while (work_done < budget);

	//DPRINT("work_done=%d, budget=%d\n", work_done, budget);
	//EXIT();
	return work_done;
}

// SWQOS_tx_process
//
// This function is the transmit handler for SWQOS.  It is called by the SWQOS tasklet to handle
// the sending of packets to the HIF-NOCPY interface.

int SWQOS_tx_process(int budget)
{
	PSWQOS_MTD pmeta;
	static PSWQOS_MTD save_pmeta = NULL;
	PSWQOS_context pcontext;
	int no_more_to_do = 1;

	pcontext = SWQOS_GET_CONTEXT();

	budget += budget / 2;	// Give Tx 1.5x of Rx budget
	while (budget > 0)
	{
		if (save_pmeta)
		{
			pmeta = save_pmeta;
			save_pmeta = NULL;
		}
		else
		{
			pmeta = SWQOS_get_data(pcontext);
			if (!pmeta)
				break;
		}
		if (!pfe_hif_nocpy_tx_packet(pmeta))
		{
			// no room to send packet -- save pointer for next time
			save_pmeta = pmeta;
			budget = 0;
			break;
		}
		pcontext->packets_processed[pmeta->queue]++;
		SWQOS_mtd_free(pmeta);
		budget--;
	}
	if (budget == 0)
		no_more_to_do = 0;	// more to do

	SWQOS_tx_congestion_discard(pcontext);
	return no_more_to_do;
}

// SWQOS_dequeue
//
// This function is used to dequeue the head packet from the selected queue.

static PSWQOS_MTD SWQOS_dequeue(PSWQOS_context pcontext, int qnum)
{
	PSWQOS_QDesc pq;
	PSWQOS_MTD head;
	PSWQOS_ShaperDesc pshaper;
	PSWQOS_SchedDesc psched;
	int shapernum;
	pq = &pcontext->q[qnum];

	// do error check
	if (pq->current_qdepth == 0)
	{
		DPRINT("current_qdepth is 0 !!\n");
		return NULL;
	}

	head = pq->head;
	if (--pq->current_qdepth != 0)
		pq->head = head->next;
	else
	{
		// queue is empty, clear active and ready bits where appropriate
		pq->ready_flag = FALSE;
		bitlist_clrbit(pcontext->active_queues, qnum);
		bitlist_for_each(pq->shaperlist, shapernum)
		{
			pshaper = &pcontext->shaper[shapernum];
			bitlist_clrbit(pshaper->active_queues, qnum);
		}
		psched = &pcontext->sched[pq->sched_num];
		bitlist_clrbit(psched->ready_queues, qnum);
		if (bitlist_get_highest(psched->ready_queues) < 0)
			bitlist_clrbit(pcontext->ready_schedulers, pq->sched_num);
	}
	pcontext->num_packets_queued--;
	//DPRINT("head=%x, tail=%x, qnum=%d, current_qdepth=%d, pktptr=%x, ready_flag=%d\n", (u32)pq->head, (u32)pq->tail, qnum, pq->current_qdepth, (u32)head->data, pq->ready_flag);
	return head;
}

// SWQOS_tx_congestion_discard
//
// This function is called by the Packet Tx Module to discard excess packets during congestion

void SWQOS_tx_congestion_discard(struct tSWQOS_context *pcontext)
{
	int qnum;
	PSWQOS_QDesc pq;
	int sched_num;
	PSWQOS_SchedDesc psched;

	if (pcontext->num_packets_queued <= SWQOS_CONGESTION_LEVEL)
		return;

	// we're congested -- reduce each queue to its max allowable depth
	//DPRINT("num_packets_queued=%d\n", pcontext->num_packets_queued);
	bitlist_for_each(pcontext->active_queues, qnum)
	{
		pq = &pcontext->q[qnum];
		while (pq->current_qdepth > pq->max_qdepth)
			SWQOS_head_drop(pcontext, qnum);
	}

	if (pcontext->num_packets_queued <= SWQOS_CONGESTION_LEVEL)
		return;

	// if we're still congested, drop packets until we're under the limit, starting with the lowest numbered scheduler
	for (sched_num = 0; sched_num < SWQOS_NUM_SCHEDULERS; sched_num++)
	{
		int max_queue;
		psched = &pcontext->sched[sched_num];
		max_queue = bitlist_get_highest(psched->qlist);
		if (max_queue < 0)	// skip scheduler if no assigned queues
			continue;
		if (psched->alg == SWQOS_ALG_PQ)
		{
			// if algorithm is PQ, drop starting from lowest priority queue
			for (qnum = 0; qnum < max_queue; qnum++)
			{
				if (!bitlist_testbit(psched->qlist, qnum))
					continue;
				pq = &pcontext->q[qnum];
				while (pq->current_qdepth != 0)
				{
					SWQOS_head_drop(pcontext, qnum);
					if (pcontext->num_packets_queued <= SWQOS_CONGESTION_LEVEL)
						return;
				}
			}
		}
		else
		{
			// if algorithm is not PQ, drop from all queues equally
			while (pcontext->num_packets_queued > SWQOS_CONGESTION_LEVEL)
			{
				int dropflag = 0;
				bitlist_for_each(psched->qlist, qnum)
				{
					pq = &pcontext->q[qnum];
					if (pq->current_qdepth != 0)
					{
						SWQOS_head_drop(pcontext, qnum);
						dropflag = 1;
					}
				}
				if (dropflag == 0)
					break;
			}
		}
		if (pcontext->num_packets_queued <= SWQOS_CONGESTION_LEVEL)
			return;
	}
}


// SWQOS_shaper
//
// This function is called by the SWQOS_get_data function to handle shaping of a set of queues.

static void SWQOS_shaper(PSWQOS_context pcontext, PSWQOS_ShaperDesc pshaper, int packet_length)
{
	int qnum;
	packet_length += pshaper->ifg;
	if ((pshaper->tokens_available -= (packet_length*BITS_PER_BYTE)) <= 0)
	{
		// Turn off ready bit in sched struct for each active queue attached to shaper.
		// If sched has no more ready queues, remove the sched from ready_schedulers list.
		bitlist_for_each(pshaper->active_queues, qnum)
		{
			PSWQOS_QDesc pq = &pcontext->q[qnum];
			PSWQOS_SchedDesc psched = &pcontext->sched[pq->sched_num];
			pq->ready_flag = FALSE;
			bitlist_clrbit(psched->ready_queues, qnum);
			if (bitlist_get_highest(psched->ready_queues) < 0)
				bitlist_clrbit(pcontext->ready_schedulers, pq->sched_num);
		}
	}
}


// SWQOS_get_data_PQ
//
// This function is called by SWQOS_get_data to select the next queue for transmission, according to the
// PQ algorithm.

static int SWQOS_get_data_PQ(PSWQOS_context pcontext, PSWQOS_SchedDesc psched)
{
	return bitlist_get_highest(psched->ready_queues);
}


// SWQOS_get_data_RR
//
// This function is called by SWQOS_get_data to select the next queue for transmission, according to the
// RR algorithm.

static int SWQOS_get_data_RR(PSWQOS_context pcontext, PSWQOS_SchedDesc psched)
{
	int qnum;
	qnum = bitlist_get_highest_subset(psched->ready_queues, psched->rr_current_queue);
	if (qnum < 0)
		qnum = bitlist_get_highest(psched->ready_queues);
	psched->rr_current_queue = qnum;
	return qnum;
}


// SWQOS_get_data_CBWFQ
//
// This function is called by SWQOS_get_data to select the next queue for transmission, according to the
// CBWFQ algorithm.

static int SWQOS_get_data_CBWFQ(PSWQOS_context pcontext, PSWQOS_SchedDesc psched)
{
	int qnum;
	int nextqnum;
	PSWQOS_QDesc pq;
	u32 soonest_finish;

	// get the first candidate
	qnum = bitlist_get_highest(psched->ready_queues);
	pq = &pcontext->q[qnum];

	// if this is the only ready queue, we're done
	nextqnum = bitlist_get_highest_subset(psched->ready_queues, qnum);
	if (nextqnum < 0)
	{
		pq->init_flag = TRUE;	// defer finish_time calc until more queues join
		return qnum;
	}

	// if first packet on the queue, init the finish time
	if (pq->init_flag)
	{
		pq->cbwfq_finish_time = pq->weight * SWQOS_LENGTH(pq->head);
		pq->init_flag = FALSE;
	}

	// we have a first candidate -- save its finish_time
	soonest_finish = pq->cbwfq_finish_time;

	// continue searching the output queues for a better candidate
	bitlist_for_each_subset(psched->ready_queues, nextqnum, nextqnum)
	{
		pq = &pcontext->q[nextqnum];

		// if first packet on the queue, init the finish time
		if (pq->init_flag)
		{
			pq->cbwfq_finish_time = pq->weight * SWQOS_LENGTH(pq->head);
			pq->init_flag = FALSE;
		}

		// if this is a better candidate, save its finish_time
		if (pq->cbwfq_finish_time < soonest_finish)
		{
			soonest_finish = pq->cbwfq_finish_time;
			qnum = nextqnum;
		}
	}

	// update finish times for next time through
	bitlist_for_each(psched->ready_queues, nextqnum)
	{
		pq = &pcontext->q[nextqnum];

		// recalculate finish time for selected queue (if this wasn't the last packet on queue)
		if (nextqnum == qnum)
		{
			if (pq->current_qdepth > 1)
				pq->cbwfq_finish_time = pq->weight * SWQOS_LENGTH(pq->head->next);
		}
		else
			pq->cbwfq_finish_time -= soonest_finish;
	}

	return qnum;
}


// SWQOS_get_data_DWRR
//
// This function is called by SWQOS_get_data to select the next queue for transmission, according to the
// DWRR algorithm.

static int SWQOS_get_data_DWRR(PSWQOS_context pcontext, PSWQOS_SchedDesc psched)
{
	PSWQOS_QDesc pq;
	int qnum;

	qnum = psched->dwrr_current_queue;
	pq = &pcontext->q[qnum];

	// Check if we need to move on to the next queue -- either we used up our credits last time,
	//	or we exhausted all of our packets, or we are rate-limited.
	if (psched->dwrr_next_flag || bitlist_testbit(psched->ready_queues, qnum) == 0)
	{
		do {
			qnum = bitlist_get_highest_subset(psched->ready_queues, qnum);
			if (qnum < 0)
				qnum = bitlist_get_highest(psched->ready_queues);
			pq = &pcontext->q[qnum];
			if (pq->dwrr_credits > 0)	// if we didn't use up credits last time, we lose them
				pq->dwrr_credits = 0;
			pq->dwrr_credits += pq->weight * psched->dwrr_mult_factor;	// replenish credits
		} while (pq->dwrr_credits <= 0);
		psched->dwrr_next_flag = FALSE;
		psched->dwrr_current_queue = qnum;
	}

	pq->dwrr_credits -= SWQOS_LENGTH(pq->head);
	if (pq->dwrr_credits <= 0)				// check if we used up our credits
		psched->dwrr_next_flag = TRUE;

	return qnum;
}


// SWQOS_get_data
//
// This function is called by the Packet Tx Module to dequeue the next packet for transmission.

PSWQOS_MTD SWQOS_get_data(PSWQOS_context pcontext)
{
	int qnum;
	int sched_num;
	int shaper_num;
	PSWQOS_MTD head;
	PSWQOS_SchedDesc psched;
	PSWQOS_QDesc pq;
	PSWQOS_ShaperDesc pshaper;

	sched_num = bitlist_get_highest(pcontext->ready_schedulers);
	if (sched_num < 0)				// return if no scheduler is ready
		return NULL;
	psched = &pcontext->sched[sched_num];
	switch (psched->alg)
	{
		case SWQOS_ALG_PQ:
		default:
			qnum = SWQOS_get_data_PQ(pcontext, psched);
			break;
		case SWQOS_ALG_RR:
			qnum = SWQOS_get_data_RR(pcontext, psched);
			break;
		case SWQOS_ALG_CBWFQ:
			qnum = SWQOS_get_data_CBWFQ(pcontext, psched);
			break;
		case SWQOS_ALG_DWRR:
			qnum = SWQOS_get_data_DWRR(pcontext, psched);
			break;
	}

	// dequeue the head packet from the selected queue
	head = SWQOS_dequeue(pcontext, qnum);
	if (!head)
	{
		DPRINT("NULL returned from SWQOS_dequeue\n");
		return NULL;
	}

	pq = &pcontext->q[qnum];
	bitlist_for_each(pq->shaperlist, shaper_num)
	{
		pshaper = &pcontext->shaper[shaper_num];
		SWQOS_shaper(pcontext, pshaper, SWQOS_LENGTH(head));
	}
	return head;
}

/*****************************************************************************
*Function Name : SWQOS_shaper_handler
*Description: This is 1ms timer function which replenishes the tokens. For every 1 ms, it 
*                   increments tokens_available variable by the value of pre-computed 
*                   tokens_per_clock_period. If tokens_available value is greater than bucket_size, 
*                   the value of tokens_available is set to bucket_size. 
******************************************************************************/

void SWQOS_shaper_handler(void)
{
	int orig_tokens_available;
	int new_tokens_available;
	PSWQOS_context pcontext;
	int shapernum;
	PSWQOS_ShaperDesc pshaper;
	int qnum;

	pcontext = SWQOS_GET_CONTEXT();
	bitlist_for_each(pcontext->enabled_shapers, shapernum)
	{
		pshaper = &pcontext->shaper[shapernum];
		if (pshaper->tokens_per_clock_period == 0)	// ignore shaper if no rate configured
			continue;
		orig_tokens_available = pshaper->tokens_available;
		new_tokens_available = orig_tokens_available + pshaper->tokens_per_clock_period;
		if (new_tokens_available > pshaper->bucket_size)
			new_tokens_available = pshaper->bucket_size;
		pshaper->tokens_available = new_tokens_available;
		if (orig_tokens_available <= 0 && new_tokens_available > 0)
		{
			// Check if any of the active queues belonging to this shaper are now ready.
			bitlist_for_each(pshaper->active_queues, qnum)
			{
				PSWQOS_QDesc pq;
				int ready_flag = TRUE;
				int temp_shaper;
				pq = &pcontext->q[qnum];
				bitlist_for_each(pq->shaperlist, temp_shaper)
				{
					if (pcontext->shaper[temp_shaper].tokens_available <= 0)
					{
						ready_flag = FALSE;
						break;
					}
				}
				// If queue just became ready, set its scheduler as ready
				if (ready_flag)
				{
					int sched_num = pq->sched_num;
					pq->ready_flag = TRUE;
					bitlist_setbit(pcontext->sched[sched_num].ready_queues, qnum);
					bitlist_setbit(pcontext->ready_schedulers, sched_num);
				}
			}
		}
	}
}

// ===============================================================================================

//  SWQOS_update_context
//
//	This function updates the context after a change to the configuration to make all context
//	values consistent.
//
static void SWQOS_update_context(PSWQOS_context pcontext)
{
	PSWQOS_QDesc pq;
	PSWQOS_ShaperDesc pshaper;
	PSWQOS_SchedDesc psched;
	int shaper_num;
	int sched_num;
	int qnum;
	BITLIST_DECLARE(old_ready_queues, SWQOS_NUM_QUEUES);
	BITLIST_DECLARE(new_ready_queues, SWQOS_NUM_QUEUES);

	// Track which queues were ready before and are ready now
	bitlist_init(old_ready_queues, SWQOS_NUM_QUEUES);
	bitlist_init(new_ready_queues, SWQOS_NUM_QUEUES);

	// Update queues.
	// If any packets are on queues that no longer have a scheduler, drop those packets.
	// Also, update each queue's ready_flag based on the current shaper config.
	bitlist_for_each(pcontext->active_queues, qnum)
	{
		pq = &pcontext->q[qnum];
		if (pq->ready_flag)
			bitlist_setbit(old_ready_queues, qnum);
		if (pq->sched_num == 0xFF)
		{
			while (pq->current_qdepth > 0)
				SWQOS_head_drop(pcontext, qnum);
			continue;
		}
		pq->ready_flag = TRUE;
		bitlist_for_each(pq->shaperlist, shaper_num)
		{
			pshaper = &pcontext->shaper[shaper_num];
			if (!pshaper->enable_flag)
				continue;
			if (pshaper->tokens_available <= 0)
				pq->ready_flag = FALSE;
		}
		if (pq->ready_flag)
			bitlist_setbit(new_ready_queues, qnum);
	}

	// update shapers
	bitlist_for_each(pcontext->enabled_shapers, shaper_num)
	{
		pshaper = &pcontext->shaper[shaper_num];
		bitlist_init(pshaper->active_queues, SWQOS_NUM_QUEUES);
		bitlist_for_each(pshaper->qlist, qnum)
		{
			if (pcontext->q[qnum].current_qdepth > 0)
				bitlist_setbit(pshaper->active_queues, qnum);
		}
	}

	// If any queues were blocked but are now ready, set their init_flag
	bitlist_for_each(new_ready_queues, qnum)
	{
		pq = &pcontext->q[qnum];
		if (!bitlist_testbit(old_ready_queues, qnum))
			pq->init_flag = TRUE;
	}

	// update schedulers
	for (sched_num = 0; sched_num < NUM_SCHEDULERS; sched_num++)
	{
		u32 dwrr_lowest_weight = 0;
		psched = &pcontext->sched[sched_num];
		bitlist_init(psched->ready_queues, SWQOS_NUM_QUEUES);
		bitlist_for_each(psched->qlist, qnum)
		{
			if (bitlist_testbit(new_ready_queues, qnum))
				bitlist_setbit(psched->ready_queues, qnum);
			if ((psched->alg == SWQOS_ALG_DWRR || psched->alg == SWQOS_ALG_CBWFQ) && pcontext->q[qnum].weight == 0)
				pcontext->q[qnum].weight = 1;
			if (psched->alg == SWQOS_ALG_DWRR)
			{
				if (dwrr_lowest_weight == 0 || pcontext->q[qnum].weight < dwrr_lowest_weight)
					dwrr_lowest_weight = pcontext->q[qnum].weight;
			}
		}
		if (psched->alg == SWQOS_ALG_DWRR)
		{
			if (dwrr_lowest_weight == 0)
				dwrr_lowest_weight = 1;
			psched->dwrr_mult_factor = (1500 / dwrr_lowest_weight) + 1;
		}
	}

	if (bitlist_get_highest(pcontext->enabled_shapers) >= 0)
		SWQOS_start_timer();
	else
		SWQOS_stop_timer();
}


//  SWQOS_reset -- reset SWQOS context to initial default values
static void SWQOS_reset(PSWQOS_context pcontext)
{
	int i;

	// Before clearing context, drop any queued packets
	for (i = 0; i < SWQOS_NUM_QUEUES; i++)
	{
		while (pcontext->q[i].current_qdepth > 0)
			SWQOS_head_drop(pcontext, i);
	}

	// Now clear the context
	memset(pcontext, 0, sizeof(SWQOS_context));

	// Init bitlists and set default values
	bitlist_init(pcontext->active_queues, SWQOS_NUM_QUEUES);
	bitlist_init(pcontext->ready_schedulers, SWQOS_NUM_SCHEDULERS);
	bitlist_init(pcontext->enabled_shapers, SWQOS_NUM_SHAPERS);

	for (i = 0; i < SWQOS_NUM_QUEUES; i++)
	{
		bitlist_init(pcontext->q[i].shaperlist, SWQOS_NUM_SHAPERS);
		pcontext->q[i].max_qdepth = DEFAULT_MAX_QDEPTH;
		pcontext->q[i].sched_num = 0xFF;
	}

	for (i = 0; i < SWQOS_NUM_SHAPERS; i++)
	{
		bitlist_init(pcontext->shaper[i].qlist, SWQOS_NUM_QUEUES);
		bitlist_init(pcontext->shaper[i].active_queues, SWQOS_NUM_QUEUES);
		pcontext->shaper[i].ifg = SWQOS_IFG_SIZE;
	}

	for (i = 0; i < SWQOS_NUM_SCHEDULERS; i++)
	{
		bitlist_init(pcontext->sched[i].qlist, SWQOS_NUM_QUEUES);
		bitlist_init(pcontext->sched[i].ready_queues, SWQOS_NUM_QUEUES);
		pcontext->sched[i].alg = SWQOS_ALG_PQ;
	}

	SWQOS_update_context(pcontext);
}


static U16 M_swqos_cmdproc(U16 cmd_code, U16 cmd_len, U16 *p)
{
	PSWQOS_context pcontext;
	U16 rtncode;
	U16 retlen = 2;
	PSWQOS_ShaperDesc pshaper;
	PSWQOS_SchedDesc psched;
	PSWQOS_QDesc pq;
	int qnum;
	int shaper_num;
	int sched_num;

	SWQOS_lock();

	pcontext = SWQOS_GET_CONTEXT();
	rtncode = CMD_OK;
	switch (cmd_code)
	{
		case CMD_SWQOS_RESET:
		{
			SWQOS_reset(pcontext);
			SWQOS_schedule();
			break;
		}
		case CMD_SWQOS_CONFIG_SHAPER:
		{
			pswqos_config_shaper_cmd_t pcmd = (pswqos_config_shaper_cmd_t)p;
			u32 bucket_size;
			if (pcmd->shaper >= SWQOS_NUM_SHAPERS)
                        {
                                rtncode = CMD_ERR;
                                break;
                        }
			shaper_num = pcmd->shaper;
			pshaper = &pcontext->shaper[shaper_num];
			if (pcmd->enable_flag == 1)
			{
				pshaper->enable_flag = TRUE;
				bitlist_setbit(pcontext->enabled_shapers, shaper_num);
			}
			else if (pcmd->enable_flag == 2)
			{
				pshaper->enable_flag = FALSE;
				bitlist_clrbit(pcontext->enabled_shapers, shaper_num);
			}
			if (pcmd->ifg != 0xFF)
				pshaper->ifg = pcmd->ifg;
			if (pcmd->rate != 0xFFFFFFFF)
			{
				/* Tokens stored in bits per 1ms clock period = (rate * bps_PER_Kbps)/MILLISEC_PER_SEC
				  * bps_PER_Kbps = 1000 & MILLISEC_PER_SEC = 1000
				  * Hence tokens per 1ms clock period = rate */
				pshaper->tokens_per_clock_period = pcmd->rate;
				pshaper->bucket_size = pshaper->tokens_per_clock_period * 2;
			}
			bucket_size = pcmd->bucket_size;
			if (bucket_size != 0xFFFFFFFF)
			{
				if (bucket_size == 0)
					bucket_size = pshaper->tokens_per_clock_period * 2;
				pshaper->bucket_size = (int)bucket_size;
			}
			if (pcmd->reset_flag)
			{
				bitlist_for_each(pshaper->qlist, qnum)
				{
					pq = &pcontext->q[qnum];
					bitlist_clrbit(pq->shaperlist, shaper_num);
				}
				bitlist_init(pshaper->qlist, SWQOS_NUM_QUEUES);
			}
			bitlist_set_from_bitarray(pshaper->qlist, pcmd->queue_array, SWQOS_NUM_QUEUES);
			bitlist_for_each(pshaper->qlist, qnum)
			{
				pq = &pcontext->q[qnum];
				bitlist_setbit(pq->shaperlist, shaper_num);
			}
			SWQOS_update_context(pcontext);
			SWQOS_schedule();
			break;
		}
		case CMD_SWQOS_CONFIG_SCHEDULER:
		{
			pswqos_config_scheduler_cmd_t pcmd = (pswqos_config_scheduler_cmd_t)p;
			u8 old_alg;
			if (pcmd->scheduler >= SWQOS_NUM_SCHEDULERS)
                        {
                                rtncode = CMD_ERR;
                                break;
                        }
			sched_num = (int)pcmd->scheduler;
			psched = &pcontext->sched[sched_num];
			old_alg = psched->alg;
			if (pcmd->algo != 0xFF)
				psched->alg = pcmd->algo;
			if (old_alg == psched->alg)
			{
				if (psched->alg == SWQOS_ALG_DWRR)
				{
					psched->dwrr_current_queue = 0;
					psched->dwrr_next_flag = 1;
				}
			}
			if (pcmd->reset_flag)
			{
				bitlist_for_each(psched->qlist, qnum)
				{
					pq = &pcontext->q[qnum];
					pq->sched_num = 0xFF;
				}
				bitlist_init(psched->qlist, SWQOS_NUM_QUEUES);
			}
			bitlist_set_from_bitarray(psched->qlist, pcmd->queue_array, SWQOS_NUM_QUEUES);
			bitlist_for_each(psched->qlist, qnum)
			{
				pq = &pcontext->q[qnum];
				if (pq->sched_num != sched_num)
				{
					if (pq->sched_num != 0xFF)
						bitlist_clrbit(pcontext->sched[pq->sched_num].qlist, qnum);
					pq->sched_num = sched_num;
					pq->alg = psched->alg;
					pq->init_flag = TRUE;
					if (pq->alg == SWQOS_ALG_DWRR)
						pq->dwrr_credits = 0;
				}
			}
			SWQOS_update_context(pcontext);
			SWQOS_schedule();
			break;
		}
		case CMD_SWQOS_CONFIG_QUEUE:
		{
			pswqos_config_queue_cmd_t pcmd = (pswqos_config_queue_cmd_t)p;
			if (pcmd->queue >= SWQOS_NUM_QUEUES)
                        {
                                rtncode = CMD_ERR;
                                break;
                        }
			qnum = (int)pcmd->queue;
			pq = &pcontext->q[qnum];
			if (pcmd->qweight != 0xFFFF)
				pq->weight = pcmd->qweight;
			if (pcmd->max_qdepth != 0xFFFF)
				pq->max_qdepth = pcmd->max_qdepth;
			SWQOS_update_context(pcontext);
			SWQOS_schedule();
			break;
		}
		case CMD_SWQOS_QUERY_SHAPER:
		{
			pswqos_query_shaper_cmd_t pcmd = (pswqos_query_shaper_cmd_t)p;
			pswqos_query_shaper_rsp_t prsp = (pswqos_query_shaper_rsp_t)p;
			if (pcmd->shaper >= SWQOS_NUM_SHAPERS)
                        {
                                rtncode = CMD_ERR;
                                break;
                        }
			shaper_num = pcmd->shaper;
			pshaper = &pcontext->shaper[shaper_num];
			memset(prsp, 0, sizeof(swqos_query_shaper_rsp_t));
			prsp->shaper = shaper_num;
			prsp->enable_flag = pshaper->enable_flag;
			prsp->ifg = pshaper->ifg;
			prsp->rate = pshaper->tokens_per_clock_period;
			prsp->bucket_size = pshaper->bucket_size;
			bitarray_copy_from_bitlist(pshaper->qlist, prsp->queue_array);
			retlen = sizeof(swqos_query_shaper_rsp_t);
			break;
		}
		case CMD_SWQOS_QUERY_SCHEDULER:
		{
			pswqos_query_scheduler_cmd_t pcmd = (pswqos_query_scheduler_cmd_t)p;
			pswqos_query_scheduler_rsp_t prsp = (pswqos_query_scheduler_rsp_t)p;
			if (pcmd->scheduler >= SWQOS_NUM_SCHEDULERS)
                        {
                                rtncode = CMD_ERR;
                                break;
                        }
			sched_num = (int)pcmd->scheduler;
			psched = &pcontext->sched[sched_num];
			memset(prsp, 0, sizeof(swqos_query_scheduler_rsp_t));
			prsp->scheduler = sched_num;
			prsp->algo = psched->alg;
			bitarray_copy_from_bitlist(psched->qlist, prsp->queue_array);
			retlen = sizeof(swqos_query_scheduler_rsp_t);
			break;
		}
		case CMD_SWQOS_QUERY_QUEUE:
		{
			pswqos_query_queue_cmd_t pcmd = (pswqos_query_queue_cmd_t)p;
			pswqos_query_queue_rsp_t prsp = (pswqos_query_queue_rsp_t)p;
			short reset_flag = pcmd->reset_flag;
			if (pcmd->queue >= SWQOS_NUM_QUEUES)
                        {
                                rtncode = CMD_ERR;
                                break;
                        }
			qnum = (int)pcmd->queue;
			pq = &pcontext->q[qnum];
			memset(prsp, 0, sizeof(swqos_query_queue_rsp_t));
			prsp->queue = qnum;
			prsp->qweight = pq->weight;
			prsp->max_qdepth = pq->max_qdepth;
			prsp->scheduler = pq->sched_num;
			prsp->packets_processed = pcontext->packets_processed[qnum];
			prsp->packets_dropped = pcontext->packets_dropped[qnum];
			if (reset_flag)
			{
				pcontext->packets_processed[qnum] = 0;
				pcontext->total_packets_dropped -= pcontext->packets_dropped[qnum];
				pcontext->packets_dropped[qnum] = 0;
			}
			bitarray_copy_from_bitlist(pq->shaperlist, prsp->shaper_array);
			retlen = sizeof(swqos_query_queue_rsp_t);
			break;
		}

		// unknown command code
		default: {
			rtncode = CMD_ERR;
			break;
		}
	}

	SWQOS_unlock();

	*p = rtncode;
	return retlen;
}

int swqos_init(void)
{
	int i;
	PSWQOS_context pcontext;

	set_cmd_handler(EVENT_SWQOS, M_swqos_cmdproc);

	// initialize the MTD free list
	for (i = 0; i < SWQOS_MAX_MTD - 1; i++)
		swqos_mtd_table[i].next = &swqos_mtd_table[i + 1];
	swqos_mtd_table[i].next = NULL;
	swqos_mtd_freelist = &swqos_mtd_table[0];

	// init to default values
	pcontext = SWQOS_GET_CONTEXT();
	SWQOS_reset(pcontext);

	return NO_ERR;
}

void swqos_exit(void)
{
	// all exit handling is done in pfe_ctrl/pfe_swqos.c (pfe_swqos_exit())
}

#endif //defined(CFG_SWQOS)
