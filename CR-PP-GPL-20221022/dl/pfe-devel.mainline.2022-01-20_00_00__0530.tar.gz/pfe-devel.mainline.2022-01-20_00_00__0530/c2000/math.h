/*
 *  Copyright (c) 2011, 2014 Freescale Semiconductor, Inc.
 *
 *  THIS FILE IS CONFIDENTIAL.
 *
 *  AUTHORIZED USE IS GOVERNED BY CONFIDENTIALITY AND LICENSE AGREEMENTS WITH FREESCALE SEMICONDUCTOR, INC.
 *
 *  UNAUTHORIZED COPIES AND USE ARE STRICTLY PROHIBITED AND MAY RESULT IN CRIMINAL AND/OR CIVIL PROSECUTION.
 */


// Note that Macros are all uppercase

#ifndef _MATH_H_
#define _MATH_H_

#include "types.h"

#if defined(COMCERTO_2000_TMU)
int get_lowest_bit(u32 val);
#endif
#if defined (CFG_PCAP) && (COMCERTO_2000_CLASS)
u32 mul(u32 n, u32 m);
u32 div(u32 a, u32 b);
#endif

#if !defined(COMCERTO_2000_CONTROL)
int get_highest_bit(U32 val);			// implemented as function on PFE
#endif	// defined(COMCERTO_2000_CONTROL)

#endif /* _MATH_H_ */
