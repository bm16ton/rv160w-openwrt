/*
 *  Copyright (c) 2011, 2014 Freescale Semiconductor, Inc.
 *
 *  THIS FILE IS CONFIDENTIAL.
 *
 *  AUTHORIZED USE IS GOVERNED BY CONFIDENTIALITY AND LICENSE AGREEMENTS WITH FREESCALE SEMICONDUCTOR, INC.
 *
 *  UNAUTHORIZED COPIES AND USE ARE STRICTLY PROHIBITED AND MAY RESULT IN CRIMINAL AND/OR CIVIL PROSECUTION.
 */


#ifndef _MODULE_TX_H_
#define _MODULE_TX_H_

#include "types.h"
#include "modules.h"
#include "layer2.h"

#if defined(COMCERTO_2000_CONTROL)

#define DEFAULT_NAME_0		eth0
#define DEFAULT_NAME_1		eth2
#define DEFAULT_NAME_2		eth3

typedef struct _tPortUpdateCommand {
	U16 portid;
	char ifname[IFNAMSIZ];
} PortUpdateCommand, *PPortUpdateCommand;


int tx_init(void);
void tx_exit(void);

#else
#include "tx.h"

void ro_tx(struct tMetadata *mtd, void *dmem_addr, void *ddr_addr, u32 num_cpy);
void M_PKT_TX_process_packet(struct tMetadata *mtd);
BOOL M_tx_enable(U32 portid) __attribute__ ((noinline));
void send_to_tx_mcast(struct tMetadata *mtd, void *dmem_addr);
void M_PKT_TX_util_process_packet(struct tMetadata *mtd, u32 pkt_type);
void *dmem_header_writeback(struct tMetadata *mtd);
void send_to_util_direct(struct tMetadata *mtd, u32 pkt_type);
int send_fragment_to_ipsec(struct tMetadata *mtd);
u32 get_pkt_seqnum(u32 pbuf_i);
#ifdef CFG_PCAP
void M_PKT_TX_process_packet_from_util(PMetadata mtd, lmem_trailer_t *trailer);
#endif

#define	send_to_tx(pMetadata) SEND_TO_CHANNEL(M_PKT_TX_process_packet, pMetadata)

#define	send_to_tx_multiple(pBeg, pEnd) SEND_TO_CHANNEL_MULTIPLE(M_PKT_TX_process_packet, pBeg, pEnd)

#endif

#endif /* _MODULE_TX_H_ */

