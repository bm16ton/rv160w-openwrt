#ifndef _CLASS_EFET_H_
#define _CLASS_EFET_H_

//#define CLASS_EFET_ASYNC	1

#define CLASS_EFET_ENTRY_ADDR		(EFET_BASE_ADDR + 0x00)
#define CLASS_EFET_ENTRY_SIZE		(EFET_BASE_ADDR + 0x04)
#define CLASS_EFET_ENTRY_DMEM_ADDR	(EFET_BASE_ADDR + 0x08)
#define CLASS_EFET_ENTRY_STATUS		(EFET_BASE_ADDR + 0x0c)
#define CLASS_EFET_ENTRY_ENDIAN		(EFET_BASE_ADDR + 0x10)

#define CBUS2DMEM	0
#define DMEM2CBUS	1

#define EFET2BUS_LE     (1 << 0)
#define PE2BUS_LE	(1 << 1)

#ifdef CLASS_EFET_ASYNC
void class_efet_async(u32 cbus_addr, u32 dmem_addr, u32 len, u32 dir);
#endif

void class_efet_sync(u32 cbus_addr, u32 dmem_addr, u32 len, u32 dir);


#endif /* _CLASS_EFET_H_ */

